﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 光源
    /// </summary>
    class Light
    {
        private Point3D lightPos;//光源
        private SColor id;//光源强度
        //private double ia;
        private SColor ka;//环境光
        public SColor Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public Point3D LightPos
        {
            get
            {
                return lightPos;
            }

            set
            {
                lightPos = value;
            }
        }

        public SColor Ka
        {
            get
            {
                return ka;
            }

            set
            {
                ka = value;
            }
        }
    }
}
