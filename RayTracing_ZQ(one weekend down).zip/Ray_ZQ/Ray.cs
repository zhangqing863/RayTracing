﻿using RayTracing_ZQ.Prefab;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 光线类
    /// </summary>
    public class Ray
    {
        Point3D _origin;//射线起点
        Vector3D _direction;//射线方向


        internal Point3D Origin
        {
            get
            {
                return _origin;
            }

            set
            {
                _origin = value;
            }
        }

        internal Vector3D Direction
        {
            get
            {
                return _direction;
            }

            set
            {
                _direction = value;
            }
        }

        ///// <summary>
        ///// 光线是否击中球体
        ///// </summary>
        ///// <param name="sphere">要判断的球体</param>
        ///// <returns></returns>
        //public bool IsHit(Sphere sphere,out Point3D hitPoint,out Vector3D normal)
        //{
        //    double a = Direction * Direction;
        //    double b = 2 * (Direction * (Origin - sphere.Center));
        //    double c = (Origin - sphere.Center) * (Origin - sphere.Center) - Math.Pow(sphere.Ridus, 2);
        //    double delta = Math.Pow(b, 2) - 4 * a * c;
        //    if(delta>=0)
        //    {
        //        //获取距离摄像机前方并离摄像机最近的t
        //        double t = (-b - Math.Sqrt(delta)) / (2 * a);
        //        if(t<0)
        //        {
        //            t = (-b + Math.Sqrt(delta)) / (2 * a);
        //        }

        //        //击中点
        //        hitPoint = GetHitPoint(t);
        //        //法线
        //        normal = sphere.GetNormalVec3(hitPoint);

        //        return true;
        //    }
        //    else
        //    {
        //        //击中点
        //        hitPoint = new Point3D();
        //        //法线
        //        normal = new Vector3D();
        //        return false;
        //    }
           
        //}

        /// <summary>
        /// 求击中点
        /// </summary>
        public Point3D GetHitPoint(double t)
        {
            return Origin + t * Direction;
        }

        public Ray()
        {
            Origin = new Point3D();
            Direction = new Vector3D();
        }

        public Ray(Point3D origin,Vector3D direction)
        {
            Origin = origin;
            Direction = direction;
        }
    }
}
