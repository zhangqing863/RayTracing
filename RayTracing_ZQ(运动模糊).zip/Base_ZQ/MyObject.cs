﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ.Base_ZQ
{
    public class MyObject
    {
        private string name;

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }


        public MyObject()
        {
            HierarchyMgr.GetInstance().allObjs.Add(this);
        }
    }
}
