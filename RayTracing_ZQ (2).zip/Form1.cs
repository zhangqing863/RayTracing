﻿using RayTracing_ZQ.Base_ZQ;
using RayTracing_ZQ.Prefab;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RayTracing_ZQ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Texture targetTexture = new Texture();
        Texture texture3 = new Texture();
        private void button1_Click(object sender, EventArgs e)
        {
            //参数设置
            Canvas myCanvas = new Canvas(1000, 500);
            //FastBitmap fastBitmap = new FastBitmap(hRes,vRes);

            World theWorld = new World();

            theWorld.Build();

            theWorld.LstGeobj[0].Material.Texture = targetTexture;

            texture3.MyBitmap = new Bitmap(@"F:\Unity资源\Texture\grass_9508.jpg");
            theWorld.LstGeobj[1].Material.Texture = texture3;


            //图像处理
            Stopwatch sw = new Stopwatch();
            sw.Start();
            PictureManager(myCanvas, theWorld);
            //fastBitmap.FastBitmapSetGradient();
            sw.Stop();

            //控件赋值
            pic.BackgroundImage = myCanvas.MyBitmap.GetThumbnailImage(pic.Width, pic.Height, null, IntPtr.Zero);
            //pic.BackgroundImage = fastBitmap.bitmap.GetThumbnailImage(pic.Width, pic.Height, null, IntPtr.Zero);
            lblTime.Text = sw.Elapsed.ToString();


        }

        //double step = 0.005;
        /// <summary>
        /// 处理图像
        /// </summary>
        /// <param name="myCanvas">要处理的画布</param>
        /// <param name="theWorld">所在的场景</param>
        private void PictureManager(Canvas myCanvas, World theWorld)
        {
            for (int i = 0; i < myCanvas.ResolutionWidth; i++)
            {
                for (int j = 0; j < myCanvas.ResolutionHeight; j++)
                {
                    //射线
                    Point3D p = new Point3D(-2 + i * myCanvas.HOffSet, 1 - j * myCanvas.VoffSet, 2);
                    //Point3D p = new Point3D(-2 + i * step, 1 - j * step, 2);
                    Vector3D dir = p - theWorld.Camera.Eye;
                    Ray ray = new Ray(theWorld.Camera.Eye, dir);

                    ShadeRec sr;

                    sr = theWorld.HitAll(ray);
                    //sphere.Hit(ray,out sr);//是否击中
                    if (sr.IsHit)
                    {
                        //交点到光源
                        Vector3D rayLight = (theWorld.PointLight.LightPos - sr.Hitpoint);
                        rayLight.Normalize();
                        //能否看到光源
                        Ray shadowRay = new Ray(sr.Hitpoint, rayLight);

                        //求取阴影光线与所有物体是否相加
                        if (!theWorld.ShadowHitAll(shadowRay))
                        {
                            //R:反射光方向
                            Vector3D R = 2 * sr.Normal * (sr.Normal * rayLight) - rayLight;
                            R.Normalize();
                            Vector3D V = theWorld.Camera.Eye - sr.Hitpoint/*p*/;
                            V.Normalize();
                            double VR = V * R;
                            double LN = rayLight * sr.Normal;
                            if (LN <= 0) LN = 0;
                            if (VR <= 0) VR = 0;

                            Material mat = sr.HitObjMat;

                            //环境光 + Lambert漫反射 + Phong镜面反射
                            //SColor sColor1 = theWorld.PointLight.Id * theWorld.PointLight.Ka;//环境光
                            SColor sColor1 = mat.MatColor * theWorld.PointLight.Ka;//环境光
                            SColor sColor2 = theWorld.PointLight.Id * mat.Kd * (LN); //Lambert漫反射
                            SColor sColor3 = theWorld.PointLight.Id * mat.Ks * Math.Pow(VR, mat.Ns); //Phong镜面反射

                            SColor Idiffuse = sColor1 + sColor2 + sColor3;
                            //光照颜色
                            Color lColor = Idiffuse.GetRGB255Color();
                            
                            //如果设置了纹理进行融合
                            if (sr.HitObjMat.Texture != null)
                            {
                                double t = 0.7;//融合权重
                                double value = (double)trackBar1.Value / (double)trackBar1.Maximum;
                                Color tColor = sr.HitObjMat.Texture.GetColor(sr, value);
                                lColor = Color.FromArgb(
                                    (int)(tColor.R * t + lColor.R * (1 - t)),
                                    (int)(tColor.G * t + lColor.G * (1 - t)),
                                    (int)(tColor.B * t + lColor.B * (1 - t))
                                    );
                            }
                                
                            myCanvas.MyBitmap.SetPixel(i, j, lColor);
                            //fastBitmap.SetArgbByte(i, j, Idiffuse);
                        }
                        else
                        {
                            myCanvas.MyBitmap.SetPixel(i, j, Color.Black);
                        }
                    }
                    else
                    {
                        myCanvas.MyBitmap.SetPixel(i, j, Color.FromArgb(45, 52, 54));
                        //fastBitmap.SetArgbByte(i, j, Color.Black);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            if(ofd.FileName!="")
                targetTexture.MyBitmap = new Bitmap(ofd.FileName);
        }

    }

}
