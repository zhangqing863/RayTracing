﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ.Base_ZQ
{
    public class Texture
    {
        private Bitmap myBitmap = new Bitmap(100, 100);
        int hres = 100;
        int vres = 100;
        public Bitmap MyBitmap
        {
            get
            {
                return myBitmap;
            }

            set
            {
                myBitmap = value; 
                hres = myBitmap.Width;
                vres = myBitmap.Height;
            }
        }

        //未归一化获取UV信息
        public void GetTextCoordinate(Vector3D normal, out int row, out int column)
        {
            double theta = Math.Acos(normal.Y);
            double phi = Math.Atan2(normal.X, normal.Z);

            if (phi < 0)
            {
                phi += 2.0 * Math.PI;
            }
            double u = phi / (2.0 * Math.PI);
            double v = 1.0 - theta / Math.PI;
            column = (int)((hres - 1) * u);
            row = (int)((vres - 1) * v);
        }
        public Color GetColor(ShadeRec sr)
        {
            int row;
            int column;
            GetTextCoordinate(sr.Normal, out row, out column);
            return myBitmap.GetPixel(column, vres - row - 1);
        }


    }

   
}
