﻿using RayTracing_ZQ.Prefab;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RayTracing_ZQ
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 生成半球形中随机射出的一条线
        /// </summary>
        Vector3D random_in_unit_sphere()
        {
            Vector3D p;
            Random r = new Random();
            do
            {
                Vector3D rndV = new Vector3D(random(),
                  random(),
                  random());

                Vector3D unitV = new Vector3D(1, 1, 1);
                p = 2.0 * rndV - unitV;

            } while (p.SqrMagnitude >= 1.0);

            return p;
        }


        public SColor Render(Ray r)
        {
            //起始光线与场景中的所有物体求交
            ShadeRec sr = word.HitAll(r);

            //物体
            if (sr.IsHit)
            {
                //已击中点为中心，半球上面生成一个随机的光线
                Point3D target = sr.Hitpoint + sr.Normal + random_in_unit_sphere();
                Vector3D dir = target - sr.Hitpoint;
                dir.Normalize();
                Ray rndRay = new Ray(sr.Hitpoint, dir);

                //递归的追踪该随机光线
                return 0.5 * Render(rndRay);
            }
            else
            {
                r.Direction.Normalize();
                double t = 0.5 * (r.Direction.Y + 1.0);

                return (1.0 - t) * new SColor(1.0, 1.0, 1.0)
                    + t * new SColor(0.5, 0.7, 1.0);
            }
        }

        /// <summary>
        /// 生成随机数
        /// </summary>
        private double random()
        {
            var seed = Guid.NewGuid().GetHashCode();
            Random r = new Random(seed);
            int i = r.Next(0, 100000);
            return (double)i / 100000;
        }

        Scene word;
        private void btnTest_Click(object sender, EventArgs e)
        {
            Render2Async(sender);
        }
        int width = 200, height=100;
        private void RenderAsync(object sender)
        {
            //观察点位置
            Point3D eye = new Point3D(0, 0, 0);

            //用于做显示的bmp---
            Bitmap bmp = new Bitmap(width, height);


            word = new Scene();

            Random r = new Random();

            //小球
            Sphere sphere = new Sphere(new Point3D(0, 0, -1), 0.5);//球体位置
            word.AddObj(sphere);


            //底部大球
            Sphere sphere3 = new Sphere(new Point3D(0, -100.5, -1), 100);//球体位置
            word.AddObj(sphere3);

            double step = 0.01;


            //采样点数量
            int sp = 100;

            Point3D p;
            Vector3D dir;
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    //颜色
                    SColor clr = new SColor(0, 0, 0);

                    //随机采样
                    for (int s = 0; s < sp; s++)
                    {
                        //成像平面上的每个点的位置
                        p = new Point3D(-2 + step * (i + random()),
                           1 - step * (j + random()),
                           -1);

                        //起始光线的方向
                        dir = p - eye;
                        dir.Normalize();
                        Ray primaryRay = new Ray(eye, dir);

                        //渲染。。。
                        clr += Render(primaryRay);
                    }
                    //
                    clr *= 1.0 / sp;

                    clr = new SColor(Math.Sqrt(clr.R),
                        Math.Sqrt(clr.G),
                        Math.Sqrt(clr.B));

                    //渲染到bmp
                    bmp.SetPixel(i, j, clr.GetRGB255Color());
                }
                //执行委托
                this.Invoke(new ShowProgressDelegate(ShowProgress), new object[] { width, i + 1});
            }
            pictureBox1.BackgroundImage = bmp.GetThumbnailImage(pictureBox1.Width, pictureBox1.Height, null, IntPtr.Zero);
        }


        #region 异步渲染过程
        private void Render2Async(object sender)
        {
            ParameterizedThreadStart start = new ParameterizedThreadStart(RenderAsync);
            Thread progressThread = new Thread(start);
            progressThread.IsBackground = true;
            progressThread.Start();
        }
        // 定义委托，异步调用
        delegate void ShowProgressDelegate(int totalStep, int currentStep);
        /// <summary>
        /// 要刷新的控件方法
        /// </summary>
        private void ShowProgress(int totalStep, int currentStep)
        {
            progressBar1.Maximum = totalStep;
            progressBar1.Value = currentStep;
        }

        #endregion

    }
}

