﻿using RayTracing_ZQ.Base_ZQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 材质
    /// </summary>
    class Material
    {
        private SColor _kd;//漫反射系数
        private SColor _ks;//镜面反射系数
        //_ns：镜面反射参数
        //越大，表面越平滑（散射现象少，视点稍一偏离，明暗亮度急剧下降）
        //越小，表面越毛糙（散射现象严重）
        private double _ns;
        private SColor _matColor;//颜色
        private double _ka;//环境光反射系数
        private Texture _texture;//材质
        public Material()
        {
            _kd = new SColor();
            _ks = new SColor();
            _ns = 0;
            _matColor = new SColor();
        }

        public Material(double ka, SColor kd, SColor ks, double ns,SColor matColor)
        {
            _ka = ka;
            _kd = kd;
            _ks = ks;
            _ns = ns;
            _matColor = matColor;
        }
        public Material(double ka, double kd, double ks, double ns, SColor matColor)
        {
            _ka = ka;
            _kd = new SColor(kd, kd, kd);
            _ks = new SColor(ks, ks, ks);
            _ns = ns;
            _matColor = matColor;
        }
        public double Ns
        {
            get
            {
                return _ns;
            }

            set
            {
                _ns = value;
            }
        }

        public Texture Texture
        {
            get
            {
                return _texture;
            }

            set
            {
                _texture = value;
            }
        }

        public double Ka
        {
            get
            {
                return _ka;
            }

            set
            {
                _ka = value;
            }
        }

        internal SColor Kd
        {
            get
            {
                return _kd;
            }

            set
            {
                _kd = value;
            }
        }

        internal SColor Ks
        {
            get
            {
                return _ks;
            }

            set
            {
                _ks = value;
            }
        }

        internal SColor MatColor
        {
            get
            {
                return _matColor;
            }

            set
            {
                _matColor = value;
            }
        }
    }
}
