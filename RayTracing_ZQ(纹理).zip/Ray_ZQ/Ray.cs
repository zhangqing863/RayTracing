﻿using RayTracing_ZQ.Prefab;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 光线类
    /// </summary>
    public class Ray
    {
        Point3D _origin;//射线起点
        Vector3D _direction;//射线方向
        double _time;//记录光线射出的时间

        internal Point3D Origin
        {
            get
            {
                return _origin;
            }

            set
            {
                _origin = value;
            }
        }

        internal Vector3D Direction
        {
            get
            {
                return _direction;
            }

            set
            {
                _direction = value;
            }
        }

        public double Time
        {
            get
            {
                return _time;
            }

            set
            {
                _time = value;
            }
        }
        /// <summary>
        /// 求击中点
        /// </summary>
        public Point3D GetHitPoint(double t)
        {
            return Origin + t * Direction;
        }

        public Ray()
        {
            Origin = new Point3D();
            Direction = new Vector3D();
        }

        public Ray(Point3D origin, Vector3D direction, double time = 0.0)
        {
            Origin = origin;
            Direction = direction;
            Time = time;
        }
    }
}
