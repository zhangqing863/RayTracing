﻿using RayTracing_ZQ.Base_ZQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ.Prefab
{
    /// <summary>
    /// 球体类
    /// </summary>
    public class Sphere: GeometryObject
    {
        //private Point3D center;//球心
        //private double ridus;//球半径



        /// <summary>
        /// 获取法线
        /// </summary>
        /// <param name="point">球面上的一点</param>
        /// <returns>法线向量</returns>
        public Vector3D GetNormalVec3(Point3D point, Point3D Center)
        {
            return (point - Center).Normalized;
        }

        /// <summary>
        /// 光线和球体的相交计算
        /// </summary>
        /// <param name="ray"></param>
        /// <param name="sr"></param>
        /// <returns></returns>
        public override bool Hit(Ray ray,out ShadeRec sr)
        {
            Point3D Center = ObjTransform.Pos.ToPoint3D();
            double Ridus = ObjTransform.Scale.X;
            Vector3D oc = ray.Origin - Center;
            double a = ray.Direction * ray.Direction;
            double b = 2 * (ray.Direction * oc);
            double c = oc * oc - Ridus * Ridus;
            double delta = b * b - 4 * a * c;
            sr = new ShadeRec();
            if (delta > 0)
            {
                //获取距离摄像机前方并离摄像机最近的t
                sr.T = (-b - Math.Sqrt(delta)) / (2 * a);
                if (sr.T < 0)
                {
                    sr.T = (-b + Math.Sqrt(delta)) / (2 * a);
                }
                if(sr.T > KEpsilon)
                {
                    //击中点
                    sr.Hitpoint = ray.GetHitPoint(sr.T);
                    //法线
                    sr.Normal = GetNormalVec3(sr.Hitpoint, Center);
                    sr.IsHit = true;
                    sr.HitObjMat = Material;
                    sr.HitObjGlobalMat = GlobalMaterial;
                    sr.Geometry = this;
                    return true;
                }
                return false;
            }
            else
            {
                return false;
            }
        }
        public const double KEpsilon = 1e-5;


        public override bool ShadowHit(Ray ray)
        {
            Vector3D oc = ray.Origin - ObjTransform.Pos.ToPoint3D();
            double a = ray.Direction * ray.Direction;
            double b = 2 * (ray.Direction * oc);
            double c = oc * oc - ObjTransform.Scale.X * ObjTransform.Scale.X;
            double delta = b * b - 4 * a * c;
            if (delta > 0)
            {
                //获取距离摄像机前方并离摄像机最近的t
                double t = (-b - Math.Sqrt(delta)) / (2.0 * a);
                if (t > KEpsilon)
                {
                    return true;
                }
                else
                {
                    //t = (-b + Math.Sqrt(delta)) / (2.0 * a);
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public Sphere()
        {
            ObjTransform = new Transform(
                new MyMatrix(0, 0, 0),
                new MyMatrix(1, 1, 1),
                new MyMatrix(0, 0, 0)
                );
        }
        public Sphere(Point3D center,double ridus)
        {
            ObjTransform = new Transform(
                new MyMatrix(center.X, center.Y, center.Z),
                new MyMatrix(ridus, ridus, ridus),
                new MyMatrix(0, 0, 0)
                );
        }
    }
}
