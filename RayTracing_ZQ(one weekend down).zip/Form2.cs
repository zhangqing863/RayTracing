﻿using RayTracing_ZQ.Prefab;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RayTracing_ZQ
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

       


        public SColor Render(Ray r,int depth)
        {
            //起始光线与场景中的所有物体求交
            ShadeRec sr = word.HitAll(r);

            Ray scattered = new Ray();

            //物体
            if (sr.IsHit&&sr.HitObjGlobalMat!=null)
            {
                if(depth < 50 && sr.HitObjGlobalMat.Scatter(r,sr,out scattered))
                {
                    return sr.HitObjGlobalMat.Attenuation * Render(scattered, depth + 1);
                }
                else
                {
                    return new SColor(0, 0, 0);
                }
            }
            else
            {
                r.Direction.Normalize();
                double t = 0.5 * (r.Direction.Y + 1.0);

                return (1.0 - t) * new SColor(1.0, 1.0, 1.0)
                    + t * new SColor(0.5, 0.7, 1.0);
            }
        }

        

        Scene word;
        private void btnTest_Click(object sender, EventArgs e)
        {
            Render2Async(sender);
        }
        int width = 2560, height=1440;
        Bitmap bmp;
        private void RenderAsync(object sender)
        {
            //Point3D lookfrom = new Point3D(13, 2, 3);
            //Point3D lookat = new Point3D(0, 0, 0);
            //double distToFocus= (lookfrom - lookat).Magnitude();
            //double aperture=0.1;
            //Camera cam = new Camera(lookfrom, lookat, new Vector3D(0, 1, 0), 20, (double)(width) / (double)(height), aperture, distToFocus);
            Point3D lookfrom = new Point3D(13, 2, 3);
            Point3D lookat = new Point3D(0, 0, 0);
            double distToFocus = 10.0;
            double aperture = 0;
            Camera cam = new Camera(lookfrom, lookat, new Vector3D(0, 1, 0), 40, (double)(width) / (double)(height), aperture, distToFocus);

            //用于做显示的bmp---
            bmp = new Bitmap(width, height);

            word = new Scene();
            Random_Scene(ref word);
            //采样点数量
            int sp = 50;
            Stopwatch sw = new Stopwatch();
            sw.Start();
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    //颜色
                    SColor clr = new SColor(0, 0, 0);

                    //随机采样
                    for (int s = 0; s < sp; s++)
                    {
                        double u = (i + Vector3D.random()) / width;
                        double v = 1 - (j + Vector3D.random()) / height;

                        Ray primaryRay = cam.GetRay(u, v);
                        int depth = 0;
                        
                        //渲染。。。
                        clr += Render(primaryRay, depth);
                    }
                    clr *= 1.0 / sp;

                    clr = new SColor(Math.Sqrt(clr.R),
                        Math.Sqrt(clr.G),
                        Math.Sqrt(clr.B));

                    //渲染到bmp
                    bmp.SetPixel(i, j, clr.GetRGB255Color());
                }
                //执行委托
                this.Invoke(new ShowProgressDelegate(ShowProgress), new object[] { width, i + 1,sw.Elapsed.ToString()});
            }
            sw.Stop();
            pictureBox1.BackgroundImage = bmp.GetThumbnailImage(pictureBox1.Width, pictureBox1.Height, null, IntPtr.Zero);
        }


        #region 异步渲染过程
        private void Render2Async(object sender)
        {
            ParameterizedThreadStart start = new ParameterizedThreadStart(RenderAsync);
            Thread progressThread = new Thread(start);
            progressThread.IsBackground = true;
            progressThread.Start();
        }
        // 定义委托，异步调用
        delegate void ShowProgressDelegate(int totalStep, int currentStep,string time);

        private void saveBtn_Click(object sender, EventArgs e)
        {
            if (bmp!=null)
            {
                SaveFileDialog sf = new SaveFileDialog();
                sf.ShowDialog();
                bmp.Save(sf.FileName);
            }
        }

        /// <summary>
        /// 要刷新的控件方法
        /// </summary>
        private void ShowProgress(int totalStep, int currentStep,string time)
        {
            progressBar1.Maximum = totalStep;
            progressBar1.Value = currentStep;
            lblTime.Text = time;
        }

        #endregion


        private void Random_Scene(ref Scene scene)
        {
            //构造平面大球
            Sphere spherePlane = new Sphere(new Point3D(0, -1000, 0), 1000);
            spherePlane.GlobalMaterial = new Lambertian(new SColor(0.5, 0.5, 0.5));

            scene.AddObj(spherePlane);

            //生成随机材质的小球
            for (int a = -10; a < 10; a++)
            {
                for (int b = -10; b < 10; b++)
                {
                    double chooseMat = Vector3D.random();
                    Point3D center = new Point3D(a + 0.9 * Vector3D.random(), 0.2, b + 0.9 * Vector3D.random());
                    if ((center - new Vector3D(4, 0.2, 0)).Magnitude()> 0.9)
                    {
                        Sphere sphere = new Sphere(center, 0.2);
                        if (chooseMat < 0.5)
                        {
                            sphere.GlobalMaterial = new Lambertian(
                                new SColor(
                                    Vector3D.random() * Vector3D.random(), 
                                    Vector3D.random() * Vector3D.random(), 
                                    Vector3D.random() * Vector3D.random()
                                    )
                                );
                            scene.AddObj(sphere);
                        }
                        else if (chooseMat < 0.75)
                        {
                            sphere.GlobalMaterial = new Metal(
                                new SColor(
                                    0.5 * (1 + Vector3D.random()),
                                    0.5 * (1 + Vector3D.random()),
                                    0.5 * (1 + Vector3D.random())
                                    )
                                , 0.5 * Vector3D.random());
                            scene.AddObj(sphere);
                        }
                        else
                        {
                            sphere.GlobalMaterial = new Dielectric(new SColor(1, 1, 1), 1.5);
                            scene.AddObj(sphere);
                        }
                    }
                }
            }

            //生成3个普通小球
            Sphere sphere1 = new Sphere(new Point3D(0, 1, 0), 1.0);
            sphere1.GlobalMaterial = new Dielectric(new SColor(1, 1, 1), 1.5);
            Sphere sphere2 = new Sphere(new Point3D(-4, 1, 0), 1.0);
            sphere2.GlobalMaterial = new Lambertian(new SColor(0.4, 0.2, 0.1));
            Sphere sphere3 = new Sphere(new Point3D(4, 1, 0), 1.0);
            sphere3.GlobalMaterial = new Metal(new SColor(0.7, 0.6, 0.5), 0);
            scene.AddObj(sphere1);
            scene.AddObj(sphere2);
            scene.AddObj(sphere3);

        }





        
    }
    }

