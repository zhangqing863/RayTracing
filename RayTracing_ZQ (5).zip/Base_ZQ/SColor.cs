﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 基础颜色类
    /// 值限定：0.0~1.0
    /// </summary>
    public class SColor
    {
        //向量x,y,z坐标
        private double r;
        private double g;
        private double b;

        public double R
        {
            get
            {
                return r;
            }
            set
            {
                r = value;
                if (r > 1)
                    r = 1;
                else if (r <= 0)
                {
                    r = 0;
                }
            }
        }
        public double G
        {
            get
            {
                return g;
            }
            set
            {
                g = value;
                if (g > 1)
                    g = 1;
                else if (g < 0)
                {
                    g = 0;
                }
            }
        }
        public double B
        {
            get
            {
                return b;
            }
            set
            {
                b = value;
                if (b > 1)
                    b = 1;
                else if (b < 0)
                {
                    b = 0;
                }
            }
        }


        public Color GetRGB255Color()
        {
            return Color.FromArgb(
                (int)(R * 255),
                (int)(G * 255),
                (int)(B * 255)
                );
        }

        public SColor()
        {
            this.R = 0;
            this.G = 0;
            this.B = 0;
        }

        public SColor(double r, double g, double b)
        {
            this.R = r;
            this.G = g;
            this.B = b;
        }

        public SColor(SColor sColor)
        {
            this.R = sColor.r;
            this.G = sColor.g;
            this.B = sColor.b;
        }

        public static SColor operator*(SColor color,double d)
        {
            return new SColor((color.R * d), (color.G * d), (color.B * d));
        }
        public static SColor operator *(double d, SColor color)
        {
            return new SColor((color.R * d), (color.G * d), (color.B * d));
        }
        public static SColor operator +(SColor color1, SColor color2)
        {
            return new SColor((color1.R + color2.R), (color1.G + color2.G), (color1.B + color2.B));
        }
        public static SColor operator *(SColor color1, SColor color2)
        {
            return new SColor((color1.R * color2.R), (color1.G * color2.G), (color1.B * color2.B));
        }
    }
}
