﻿using RayTracing_ZQ.Prefab;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RayTracing_ZQ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        /// <summary>
        /// 创建世界
        /// </summary>
        /// <param name="theWorld"></param>
        private static void WorldBuild(World theWorld)
        {

            theWorld.eye = new Point3D(0, 0, 0);//视线起点
            theWorld.light = new Point3D(-1, 2, -1);//光照- 1, 1, 0.5
            theWorld.ka = 0.4;//环境光
            theWorld.Id = new SColor(1, 1, 1);//光源强度

            Sphere sphere = new Sphere(new Point3D(0, 0, -1), 0.5);//生成圆-材质
            Material mt = new Material(0.8, 0.5, 50, new SColor(
            1, 1, 1));
            sphere.Material = mt;
            theWorld.AddObj(sphere);



            Sphere sphere1 = new Sphere(new Point3D(0, -100.5, -1.0), 100);//生成圆-材质
            Material mt1 = new Material(0.1, 0.8, 1000, new SColor(
            0, 0, 1));
            sphere1.Material = mt1;
            theWorld.AddObj(sphere1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //参数设置
            int hRes = 1000;
            int vRes = 500;
            double HOffSet = 4.0 / hRes;
            double VoffSet = 2.0 / vRes;
            //FastBitmap fastBitmap = new FastBitmap(hRes,vRes);
            Bitmap bitmap = new Bitmap(hRes, vRes);

            World theWorld = new World();
            WorldBuild(theWorld);

            //图像处理
            Stopwatch sw = new Stopwatch();
            sw.Start();
            for (int i = 0; i < hRes; i++)
            {
                for (int j = 0; j < vRes; j++)
                {
                    //射线
                    Point3D p = new Point3D(-2 + i * HOffSet, 1 - j * VoffSet, -1);
                    Vector3D dir = p - theWorld.eye;
                    Ray ray = new Ray(theWorld.eye, dir);

                    ShadeRec sr;

                    sr = theWorld.HitAll(ray);
                    //sphere.Hit(ray,out sr);//是否击中
                    if (sr.IsHit)
                    {
                        //交点到光源
                        Vector3D L = (theWorld.light - sr.Hitpoint);
                        L.Normalize();
                        //能否看到光源
                        Ray shadowRay = new Ray(sr.Hitpoint, L);
                        if (theWorld.ShadowHitAll(shadowRay))
                        {
                            bitmap.SetPixel(i, j, Color.Black);
                        }
                        else
                        {
                            //R:反射光方向
                            Vector3D R = 2 * (sr.Normal * L) * sr.Normal - L;
                            R.Normalize();
                            Vector3D V = theWorld.eye - sr.Hitpoint;
                            V.Normalize();
                            double VR = V * R;
                            double LN = L * sr.Normal;
                            if (LN <= 0) LN = 0;
                            if (VR <= 0) VR = 0;

                            //环境光 + Lambert漫反射 + Phong镜面反射
                            SColor sColor1 = theWorld.Id * sr.HitObjMat.Kd * (LN);
                            SColor sColor2 = sr.HitObjMat.MatColor * theWorld.ka;
                            SColor sColor3 = theWorld.Id * sr.HitObjMat.Ks * Math.Pow(VR, sr.HitObjMat.Ns);

                            SColor Idiffuse = sColor1 + sColor2 + sColor3;


                            bitmap.SetPixel(i, j, Idiffuse.GetRGB255Color());
                            //fastBitmap.SetArgbByte(i, j, Idiffuse);
                        }
                    }
                    else
                    {
                        bitmap.SetPixel(i, j, Color.FromArgb(45, 52, 54));
                        //fastBitmap.SetArgbByte(i, j, Color.Black);
                    }
                }
            }
            //fastBitmap.FastBitmapSetGradient();
            sw.Stop();


            //控件赋值
            pic.BackgroundImage = bitmap.GetThumbnailImage(pic.Width, pic.Height, null, IntPtr.Zero);
            //pic.BackgroundImage = fastBitmap.bitmap.GetThumbnailImage(pic.Width, pic.Height, null, IntPtr.Zero);
            lblTime.Text = sw.Elapsed.ToString();
        }

        
    }

}
