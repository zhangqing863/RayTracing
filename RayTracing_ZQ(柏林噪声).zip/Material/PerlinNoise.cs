﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    public class PerlinNoise
    {
        public static int[] perm_x = Perlin_Generate_Perm(); 
        public static int[] perm_y = Perlin_Generate_Perm();
        public static int[] perm_z = Perlin_Generate_Perm();
        public static Vector3D[] ranVector3D = Perlin_Generate();



        public double Noise(Point3D pos)
        {
            double u = pos.X - Math.Floor(pos.X);
            double v = pos.Y - Math.Floor(pos.Y);
            double w = pos.Z - Math.Floor(pos.Z);

            int i = (int)/*Math.Abs*/(Math.Floor(pos.X));
            int j = (int)/*Math.Abs*/(Math.Floor(pos.Y));
            int k= (int)/*Math.Abs*/(Math.Floor(pos.Z));
            Vector3D[,,] c = new Vector3D[2, 2, 2];

            for (int di = 0; di < 2; di++)
            {
                for (int dj = 0; dj < 2; dj++)
                {
                    for (int dk = 0; dk < 2; dk++)
                    {
                        c[di, dj, dk] = ranVector3D[
                            perm_x[(i + di) & 255] ^
                            perm_x[(j + dj) & 255] ^
                            perm_x[(k + dk) & 255]
                            ];
                    }
                }
            }
            return Trilinear_Interp(c, u, v, w);
        }

        /// <summary>
        /// 生成柏林数据
        /// </summary>
        /// <returns></returns>
        public static Vector3D[] Perlin_Generate()
        {
            Vector3D[] p = new Vector3D[256];
            for (int i = 0; i < 256; ++i)
            {
                double x_random = 2 * Vector3D.random() - 1;
                double y_random = 2 * Vector3D.random() - 1;
                double z_random = 2 * Vector3D.random() - 1;
                p[i] = new Vector3D(x_random, y_random, z_random).Normalized;
            }
            return p;
        }

        /// <summary>
        /// 置换
        /// </summary>
        /// <param name="p"></param>
        /// <param name="n"></param>
        public static void Permute(int[] p, int n)
        {
            for (int i = n - 1; i > 0; i--)
            {
                int target = (int)(Vector3D.random() * (i + 1));
                int tmp = p[i];
                p[i] = p[target];
                p[target] = tmp;
            }
        }

        /// <summary>
        /// 产生置换后的柏林数据
        /// </summary>
        public static int[] Perlin_Generate_Perm()
        {
            int[] p = new int[256];
            for (int i = 0; i < 256; i++)
                p[i] = i;
            Permute(p, 256);
            return p;
        }

        /// <summary>
        /// 三线性插值
        /// </summary>
        public static double Trilinear_Interp(Vector3D[,,] c, double u,double v,double w)
        {
            double uu = u * u * (3 - 2 * u);
            double vv = v * v * (3 - 2 * v);
            double ww = w * w * (3 - 2 * w);
            double accum = 0;
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    for (int k = 0; k < 2; k++)
                    {
                        Vector3D weight_v = new Vector3D(u - i, v - j, w - k);
                        accum += (i * uu + (1 - i) * (1 - uu)) *
                                          (j * vv + (1 - j) * (1 - vv)) *
                                          (k * ww + (1 - k) * (1 - ww)) * (c[i, j, k] * weight_v);
                    }
                }
            }
            return accum;
        }
        /// <summary>
        /// 湍流
        /// </summary>
        public double Turb(Point3D p, int depth = 7)
        {
            double accum = 0;
            Point3D temp_p = p;
            double weight = 1.0;
            for (int i = 0; i < depth; i++)
            {
                accum += weight * Noise(temp_p);
                weight *= 0.5;
                temp_p = 2 * temp_p;
            }
            return Math.Abs(accum);
        }

    }
}
