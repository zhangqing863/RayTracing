﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ.Prefab
{
    /// <summary>
    /// 球体类
    /// </summary>
    public class Sphere: GeometryObject
    {
        private Point3D center;//球心
        private double ridus;//球半径

        internal Point3D Center
        {
            get
            {
                return center;
            }

            set
            {
                center = value;
            }
        }

        public double Ridus
        {
            get
            {
                return ridus;
            }

            set
            {
                ridus = value;
            }
        }

        /// <summary>
        /// 获取法线
        /// </summary>
        /// <param name="point">球面上的一点</param>
        /// <returns>法线向量</returns>
        public Vector3D GetNormalVec3(Point3D point)
        {
            return (point - Center);
        }

        /// <summary>
        /// 光线和球体的相交计算
        /// </summary>
        /// <param name="ray"></param>
        /// <param name="sr"></param>
        /// <returns></returns>
        public override bool Hit(Ray ray,out ShadeRec sr)
        {
            Vector3D oc = ray.Origin - Center;
            double a = ray.Direction * ray.Direction;
            double b = 2 * (ray.Direction * oc);
            double c = oc * oc - Ridus * Ridus;
            double delta = b * b - 4 * a * c;
            sr = new ShadeRec();
            if (delta > 0)
            {
                //获取距离摄像机前方并离摄像机最近的t
                sr.T = (-b - Math.Sqrt(delta)) / (2 * a);
                if (sr.T < 0)
                {
                    sr.T = (-b + Math.Sqrt(delta)) / (2 * a);
                }
                if(sr.T > KEpsilon)
                {
                    //击中点
                    sr.Hitpoint = ray.GetHitPoint(sr.T);
                    //法线
                    sr.Normal = GetNormalVec3(sr.Hitpoint);
                    sr.IsHit = true;
                    sr.HitObjMat = Material;
                    return true;
                }
                return false;
            }
            else
            {
                return false;
            }
        }
        public const double KEpsilon = 1e-5;


        public override bool ShadowHit(Ray ray)
        {
            Vector3D oc = ray.Origin - Center;
            double a = ray.Direction * ray.Direction;
            double b = 2 * (ray.Direction * oc);
            double c = oc * oc - Ridus * Ridus;
            double delta = b * b - 4 * a * c;
            if (delta > 0)
            {
                //获取距离摄像机前方并离摄像机最近的t
                double t = (-b - Math.Sqrt(delta)) / (2.0 * a);
                if (t > KEpsilon)
                {
                    return true;
                }
                else
                {
                    //t = (-b + Math.Sqrt(delta)) / (2.0 * a);
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public Sphere()
        {
            Center = new Point3D(0, 0, 0);
            Ridus = 0;
        }
        public Sphere(Point3D center,double ridus)
        {
            Center = center;
            Ridus = ridus;
        }
    }
}
