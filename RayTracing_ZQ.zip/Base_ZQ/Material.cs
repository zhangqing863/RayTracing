﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 材质
    /// </summary>
    class Material
    {
        private SColor _kd;//漫反射系数
        private SColor _ks;//镜面反射系数
        private double _ns;//高光指数
        private SColor _matColor;//颜色
        public Material()
        {
            _kd = new SColor();
            _ks = new SColor();
            _ns = 0;
            _matColor = new SColor();
        }

        public Material(SColor kd, SColor ks, double ns,SColor matColor)
        {
            _kd = kd;
            _ks = ks;
            _ns = ns;
            _matColor = matColor;
        }
        public Material(double kd, double ks, double ns, SColor matColor)
        {
            _kd = new SColor(kd, kd, kd);
            _ks = new SColor(ks, ks, ks);
            _ns = ns;
            _matColor = matColor;
        }
        public double Ns
        {
            get
            {
                return _ns;
            }

            set
            {
                _ns = value;
            }
        }


        internal SColor Kd
        {
            get
            {
                return _kd;
            }

            set
            {
                _kd = value;
            }
        }

        internal SColor Ks
        {
            get
            {
                return _ks;
            }

            set
            {
                _ks = value;
            }
        }

        internal SColor MatColor
        {
            get
            {
                return _matColor;
            }

            set
            {
                _matColor = value;
            }
        }
    }
}
