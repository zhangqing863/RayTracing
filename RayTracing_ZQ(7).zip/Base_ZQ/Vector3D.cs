﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 向量类
    /// </summary>
    public class Vector3D
    {
        //向量x,y,z坐标
        private double x;
        private double y;
        private double z;

        public double X
        {
            get => x;
            set => x = value;
        }
        public double Y
        {
            get => y;
            set => y = value;
        }
        public double Z
        {
            get => z;
            set => z = value;
        }

        /// <summary>
        /// 生成半球形中随机射出的一条线
        /// </summary>
        public static Vector3D random_in_unit_sphere()
        {
            Vector3D p;
            Random r = new Random();
            do
            {
                Vector3D rndV = new Vector3D(random(),
                  random(),
                  random());

                Vector3D unitV = new Vector3D(1, 1, 1);
                p = 2.0 * rndV - unitV;

            } while (p.SqrMagnitude >= 1.0);

            return p;
        }
        private static double random()
        {
            var seed = Guid.NewGuid().GetHashCode();
            Random r = new Random(seed);
            int i = r.Next(0, 100000);
            return (double)i / 100000;
        }

        #region 构造函数
        public Vector3D()
        {
            this.X = 0;
            this.Y = 0;
            this.Z = 0;
        }

        public Vector3D(double x, double y, double z)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }

        public Vector3D(Vector3D _v)
        {
            this.X = _v.x;
            this.Y = _v.y;
            this.Z = _v.z;
        }
        #endregion

        #region 运算符重载
        //向量相减
        public static Vector3D operator -(Vector3D v1, Vector3D v2)
        {
            return new Vector3D(v1.X - v2.X, v1.Y - v2.Y, v1.Z - v2.Z);
        }
        //向量相加
        public static Vector3D operator +(Vector3D v1, Vector3D v2)
        {
            return new Vector3D(v1.X + v2.X, v1.Y + v2.Y, v1.Z + v2.Z);
        }
        
        //向量与标量相乘
        public static Vector3D operator *(Vector3D v1, double lenth)
        {
            return new Vector3D(v1.X * lenth, v1.Y * lenth, v1.Z * lenth);
        }
        //标量与向量相乘
        public static Vector3D operator *(double lenth,Vector3D v1)
        {
            return new Vector3D(v1.X * lenth, v1.Y * lenth, v1.Z * lenth);
        }

        //向量与向量相乘
        public static double operator *(Vector3D v1, Vector3D v2)
        {
            return (v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z);
        }
        #endregion

        #region 归一化

        //向量的模长
        public double Magnitude()
        {
            return Math.Sqrt(X * X + Y * Y + Z * Z);
        }
        private double sqrMagnitude;
        public double SqrMagnitude
        {
            get
            {
                return (X * X + Y * Y + Z * Z); ;
            }
        }


        //求本向量的单位向量，本向量不改变
        private  Vector3D normalized;
        internal  Vector3D Normalized
        {
            get
            {
                double d = Magnitude();
                normalized = new Vector3D(X / d, Y / d, Z / d);
                return normalized;
            }
        }

        

        //本向量的单位向量，本向量改变
        public void Normalize()
        {
            double d = Magnitude();
            X /= d;
            Y /= d;
            Z /= d;
        }

        #endregion
    }
}
