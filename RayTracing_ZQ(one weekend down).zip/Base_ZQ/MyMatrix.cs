﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ.Base_ZQ
{
    /// <summary>
    /// 用于旋转、放缩、平移使用的矩阵
    /// </summary>
    class MyMatrix
    {
        double x;
        double y;
        double z;

        public double X
        {
            get
            {
                return x;
            }

            set
            {
                x = value;
            }
        }

        public double Y
        {
            get
            {
                return y;
            }

            set
            {
                y = value;
            }
        }

        public double Z
        {
            get
            {
                return z;
            }

            set
            {
                z = value;
            }
        }

        public MyMatrix(double x,double y,double z)
        {
            X = x;
            Y = y;
            Z = z;
        }
        /// <summary>
        /// 放缩
        /// </summary>
        /// <param name="sx"></param>
        /// <param name="sy"></param>
        /// <param name="sz"></param>
        /// <returns></returns>
        public void Scale(double sx, double sy, double sz)
        {
            X = X * sx;
            Y = Y * sy;
            Z = Z * sz;
        }
        /// <summary>
        /// 平移
        /// </summary>
        /// <param name="sx"></param>
        /// <param name="sy"></param>
        /// <param name="sz"></param>
        /// <returns></returns>
        public void Translate(double tx, double ty, double tz)
        {
            X = X + tx;
            Y = Y + ty;
            Z = Z + tz;
        }

        public void RotateAtX(double angle)
        {
            Y = Y * Math.Cos(angle)-Z*Math.Sin(angle);
            Z = Y * Math.Sin(angle) + Z * Math.Cos(angle);
        }
        public void RotateAtY(double angle)
        {
            X = X * Math.Cos(angle) + Z * Math.Sin(angle);
            Z = -X * Math.Sin(angle) + Z * Math.Cos(angle);
        }
        public void RotateAtZ(double angle)
        {
            X = X * Math.Cos(angle) - Y * Math.Sin(angle);
            Y = X * Math.Sin(angle) + Y * Math.Cos(angle);
        }

        public Point3D ToPoint3D()
        {
            return new Point3D(X, Y, Z);
        }
    }
}
