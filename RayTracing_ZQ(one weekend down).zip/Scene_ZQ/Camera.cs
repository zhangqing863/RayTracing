﻿using RayTracing_ZQ.Base_ZQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 摄像机
    /// </summary>
    class Camera:MyObject
    {
        private Point3D eye;//视线

        public Point3D Eye
        {
            get
            {
                return eye;
            }

            set
            {
                eye = value;
            }
        }

        public Point3D LowerLeftCorner
        {
            get
            {
                return lowerLeftCorner;
            }

            set
            {
                lowerLeftCorner = value;
            }
        }

        public Vector3D Horizontal
        {
            get
            {
                return horizontal;
            }

            set
            {
                horizontal = value;
            }
        }

        public Vector3D Vertical
        {
            get
            {
                return vertical;
            }

            set
            {
                vertical = value;
            }
        }

        public Point3D Origin
        {
            get
            {
                return origin;
            }

            set
            {
                origin = value;
            }
        }

        private Point3D lowerLeftCorner;
        private Vector3D horizontal;//水平方向
        private Vector3D vertical;//垂直方向
        private Point3D origin; 
        Vector3D u = new Vector3D();
        Vector3D v = new Vector3D();
        Vector3D w = new Vector3D();
        private Random random = new Random();
        private double lensRadius;
        public Camera()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="lookfrom">摄像头的位置</param>
        /// <param name="lookat">查看的点</param>
        /// <param name="vup">朝上方向的向量</param>
        /// <param name="vfov">从上到下的度数</param>
        /// <param name="aspect">比例</param>
        public Camera(Point3D lookfrom, Point3D lookat, Vector3D vup, double vfov, double aspect, double aperture, double focusDist)
        {
            lensRadius = aperture / 2;
            double thete = vfov * Math.PI / 180;
            double halfHeight = Math.Tan(thete / 2);
            double halfWidth = aspect * halfHeight;
            origin = lookfrom;
            w = (lookfrom - lookat).Normalized;
            u = (Vector3D.Cross(vup, w)).Normalized;
            v = Vector3D.Cross(w, u);
            Vector3D lowerLeftCornerTemp = origin - halfWidth * focusDist * u - halfHeight * focusDist * v - w * focusDist;
            lowerLeftCorner = new Point3D(lowerLeftCornerTemp.X, lowerLeftCornerTemp.Y, lowerLeftCornerTemp.Z);
            Horizontal = 2 * halfWidth * u * focusDist;
            Vertical = 2 * halfHeight * v * focusDist;
        }
        /// <summary>
        /// 获取从摄像机发出的光线
        /// </summary>
        public Ray GetRay(double s, double t)
        {
            Vector3D rd = lensRadius * RandomInUnitDisk();
            Vector3D offset = u * rd.X + v * rd.Y; //偏移量，为了方便用Vector表示
            return new Ray(new Point3D(Origin.X+offset.X, Origin.Y+ offset.Y, Origin.Z + offset.Z), LowerLeftCorner + s * Horizontal + t *
            Vertical - Origin - offset);
        }

        Vector3D RandomInUnitDisk()
        {
            Vector3D p;
            do
            {
                p = 2.0 * new Vector3D(random.NextDouble(), random.NextDouble(), 0) - new Vector3D(1, 1, 0);
            } while (p*p >= 1.0);
            return p;
        }
    }
}
