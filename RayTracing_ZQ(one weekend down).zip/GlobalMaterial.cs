﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    public abstract class GlobalMaterial
    {
        SColor attenuation;//衰减
        public Random random = new Random();
        public SColor Attenuation
        {
            get
            {
                return attenuation;
            }

            set
            {
                attenuation = value;
            }
        }
        public GlobalMaterial(SColor a)
        {
            Attenuation = a;
        }

        /// <summary>
        /// 散射特性----漫发射，镜面反射
        /// </summary>
        /// <param name="rayIn">入射光线</param>
        /// <param name="sr">击中点信息</param>
        /// <param name="scattered">散射光线</param>
        /// <returns></returns>
        public abstract bool Scatter(Ray rayIn, ShadeRec sr, out Ray scattered);

        /// <summary>
        /// 计算反射向量
        /// </summary>
        public Vector3D GetReflectDir(Vector3D v, Vector3D n)
        {
            v.Normalize();
            n.Normalize();
            return v - 2 * (v * n) * n;
        }


        /// <summary>
        /// 求取折射方向
        /// </summary>
        /// <param name="v">入射方向</param>
        /// <param name="n">法线</param>
        /// <param name="niOverNt">系数</param>
        /// <param name="refracted">折射方向</param>
        public bool Refract(Vector3D v, Vector3D n, double niOverNt, ref Vector3D refracted)
        {
            v.Normalize();
            Vector3D uv = v;
            double dt = uv * n;
            double discriminant = 1.0 - niOverNt * niOverNt * (1 - dt * dt);
            if (discriminant > 0)
            {
                refracted = niOverNt * (uv - n * dt) - n * Math.Sqrt(discriminant);
                return true;
            }
            else
                return false;
        }
    }

    /// <summary>
    /// 兰伯特材质
    /// </summary>
    class Lambertian : GlobalMaterial
    {
        public Lambertian(SColor clr) : base(clr)
        {
        }
        //随机漫反射
        public override bool Scatter(Ray rayIn, ShadeRec sr, out Ray scattered)
        {
            Point3D target = sr.HitPoint + sr.Normal + Vector3D.random_in_unit_sphere();
            scattered = new Ray(sr.HitPoint, target - sr.HitPoint);
            return true;
        }
    }

    /// <summary>
    /// 金属材质
    /// </summary>
    class Metal : GlobalMaterial
    {
        /// <summary>
        /// 哑光系数
        /// </summary>
        private double fuzz;
        public Metal(SColor clr, double fuzz = 0) : base(clr)
        {
            this.Fuzz = fuzz;
        }

        public double Fuzz
        {
            get
            {
                return fuzz;
            }

            set
            {
                fuzz = value;
            }
        }

        //镜面反射
        public override bool Scatter(Ray rayIn, ShadeRec sr, out Ray scattered)
        {
            Vector3D reflectedDir = GetReflectDir(rayIn.Direction, sr.Normal);
            reflectedDir.Normalize();

            scattered = new Ray(sr.HitPoint, reflectedDir + Fuzz * Vector3D.random_in_unit_sphere());
            scattered.Direction.Normalize();
            return (scattered.Direction * sr.Normal) > 0;
        }


    }


    ///// <summary>
    ///// 电介质（玻璃）
    ///// </summary>
    //class Dielectric : GlobalMaterial
    //{
    //    private double refIdx; //相对折射率
    //    public double RefIdx { get => refIdx; set => refIdx = value; }
    //    public Dielectric(SColor clr, double refIdx) : base(clr)
    //    {
    //        this.RefIdx = refIdx;
    //    }
    //    public override bool Scatter(Ray rayIn, ShadeRec sr, out Ray scattered)
    //    {
    //        Vector3D outwardNormal = new Vector3D();
    //        Vector3D reflectedDir = GetReflectDir(rayIn.Direction, sr.Normal);
    //        double niOverNt;//ni/nt
    //        Vector3D refracted = new Vector3D();//折射向量

    //        double reflect_prob;
    //        double cosine;

    //        if (rayIn.Direction * sr.Normal > 0)
    //        {
    //            outwardNormal = sr.Normal * (-1);
    //            niOverNt = refIdx;

    //            cosine = refIdx * (rayIn.Direction * sr.Normal) / rayIn.Direction.Magnitude();
    //        }
    //        else
    //        {
    //            outwardNormal = sr.Normal;
    //            niOverNt = 1.0 / refIdx;

    //            cosine = -(rayIn.Direction * sr.Normal) / rayIn.Direction.Magnitude();
    //        }

    //        if (Refract(rayIn.Direction, outwardNormal, niOverNt, ref refracted))
    //        {
    //            reflect_prob = Schlick(cosine, refIdx);
    //        }
    //        else
    //        {
    //            scattered = new Ray(sr.HitPoint, reflectedDir);
    //            reflect_prob = 1.0;
    //        }
    //        if (random.NextDouble() < reflect_prob)
    //        {
    //            scattered = new Ray(sr.HitPoint, reflectedDir);
    //        }
    //        else
    //        {
    //            scattered = new Ray(sr.HitPoint, refracted);
    //        }
    //        return true;
    //    }

    //    public static double Schlick(double cosine, double refIdx)
    //    {
    //        double r0 = (1 - refIdx) / (1 + refIdx);
    //        r0 = r0 * r0;
    //        return r0 + (1 - r0) * Math.Pow((1 - cosine), 5);
    //    }



    //}

    class Dielectric : GlobalMaterial
    {
        private double refIdx; //相对折射率
        public Dielectric(SColor clr, double refIdx) : base(clr)
        {
            this.RefIdx = refIdx;
        }
        public Vector3D GetReflectDir(Vector3D v, Vector3D n)
        {
            v.Normalize();
            n.Normalize();
            return v - 2 * (v * n) * n;
        }
        public double RefIdx { get => refIdx; set => refIdx = value; }

        public static bool Refract(Vector3D v, Vector3D n, double niOverNt, ref
        Vector3D refracted)
        {
            v.Normalize();
            Vector3D uv = v;
            double dt = uv * n;
            double discriminant = 1.0 - niOverNt * niOverNt * (1 - dt * dt);
            if (discriminant > 0)
            {
                refracted = niOverNt * (uv - n * dt) - n *
               Math.Sqrt(discriminant);
                return true;
            }
            else
                return false;
        }

        public override bool Scatter(Ray rayln, ShadeRec sr, out Ray rayScatter)
        {
            Vector3D outwardNormal = new Vector3D();
            Vector3D reflected = GetReflectDir(rayln.Direction, sr.Normal);
            double niOverNt;
            //attenuation = new Vector3(1, 1, 1); //衰减率
            Vector3D refracted = new Vector3D();
            if ((rayln.Direction * sr.Normal) > 0)
            {
                outwardNormal = sr.Normal * -1;
                niOverNt = refIdx;
            }
            else
            {
                outwardNormal = sr.Normal;
                niOverNt = 1.0 / refIdx;
            }
            if (Refract(rayln.Direction, outwardNormal, niOverNt, ref refracted))
            {
                rayScatter = new Ray(sr.HitPoint, refracted);
            }
            else
            {
                rayScatter = new Ray(sr.HitPoint, reflected);
                return false;
            }
            return true;
        }
    }
}
