﻿using RayTracing_ZQ.Base_ZQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 几何体
    /// </summary>
    public abstract class GeometryObject:MyObject
    {
        private Material _material;//几何体材质
        private Transform _objTransform;//坐标

        internal Material Material
        {
            get
            {
                return _material;
            }

            set
            {
                _material = value;
            }
        }

        internal Transform ObjTransform
        {
            get
            {
                return _objTransform;
            }

            set
            {
                _objTransform = value;
            }
        }

        /// <summary>
        /// 光线射击
        /// </summary>
        /// <param name="ray">光线</param>
        /// <param name="sr">击中点信息</param>
        /// <returns></returns>
        public abstract bool Hit(Ray ray, out ShadeRec sr);
        /// <summary>
        /// 判断阴影
        /// </summary>
        /// <param name="ray"></param>
        /// <returns></returns>
        public abstract bool ShadowHit(Ray ray);



    }
}
