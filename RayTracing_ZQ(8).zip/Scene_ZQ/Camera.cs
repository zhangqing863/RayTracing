﻿using RayTracing_ZQ.Base_ZQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 摄像机
    /// </summary>
    class Camera:MyObject
    {
        private Point3D eye;//视线

        public Point3D Eye
        {
            get
            {
                return eye;
            }

            set
            {
                eye = value;
            }
        }

        public Point3D LowerLeftCorner
        {
            get
            {
                return lowerLeftCorner;
            }

            set
            {
                lowerLeftCorner = value;
            }
        }

        public Vector3D Horizontal
        {
            get
            {
                return horizontal;
            }

            set
            {
                horizontal = value;
            }
        }

        public Vector3D Vertical
        {
            get
            {
                return vertical;
            }

            set
            {
                vertical = value;
            }
        }

        public Point3D Origin
        {
            get
            {
                return origin;
            }

            set
            {
                origin = value;
            }
        }

        private Point3D lowerLeftCorner;
        private Vector3D horizontal;
        private Vector3D vertical;
        private Point3D origin;
        public Camera()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="lookfrom">摄像头的位置</param>
        /// <param name="lookat">查看的点</param>
        /// <param name="vup">指定上方向向量的方法</param>
        /// <param name="vfov">从上到下的度数</param>
        /// <param name="aspect">比例</param>
        public Camera(Point3D lookfrom, Point3D lookat, Vector3D vup, double vfov, double aspect)
        {
            Vector3D u = new Vector3D();
            Vector3D v = new Vector3D();
            Vector3D w = new Vector3D();
            double thete = vfov * Math.PI / 180;
            double halfHeight = Math.Tan(thete / 2);
            double halfWidth = aspect * halfHeight;
            origin = lookfrom;
            w = (lookfrom - lookat).Normalized;
            u = (Vector3D.Cross(vup, w)).Normalized;
            v = Vector3D.Cross(w, u);
            lowerLeftCorner = new Point3D(-halfWidth, -halfHeight, -1.0);
            Vector3D lowerLeftCornerTemp = origin - halfWidth * u - halfHeight * v - w;
            lowerLeftCorner = new Point3D(lowerLeftCornerTemp.X, lowerLeftCornerTemp.Y, lowerLeftCornerTemp.Z);
            Horizontal = 2 * halfWidth * u;
            Vertical = 2 * halfHeight * v;
        }
        /// <summary>
        /// 获取从摄像机发出的光线
        /// </summary>
        public Ray GetRay(double s, double t)
        {
            return new Ray(Origin, LowerLeftCorner + s * Horizontal + t * Vertical - Origin);
        }
    }
}
