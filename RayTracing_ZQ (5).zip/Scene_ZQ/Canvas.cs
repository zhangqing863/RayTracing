﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{

    /// <summary>
    /// 绘制图像的画布
    /// </summary>
    class Canvas
    {
        //分辨率
        private int resolutionWidth;
        private int resolutionHeight;
        //偏移量
        private double hOffSet;
        private double voffSet;
        //被操作的图像

        private Bitmap bitmap;
        public Canvas(int resolutionWidth,int resolutionHeight)//设定以及初始化
        {
            ResolutionWidth = resolutionWidth;
            ResolutionHeight = resolutionHeight;
            MyBitmap = new Bitmap(resolutionWidth,resolutionHeight);
            HOffSet = 4.0 / resolutionWidth;
            VoffSet = 2.0 / resolutionHeight;
        }


        public Bitmap MyBitmap
        {
            get
            {
                return bitmap;
            }

            set
            {
                bitmap = value;
            }
        }

        public int ResolutionWidth
        {
            get
            {
                return resolutionWidth;
            }

            set
            {
                resolutionWidth = value;
            }
        }

        public int ResolutionHeight
        {
            get
            {
                return resolutionHeight;
            }

            set
            {
                resolutionHeight = value;
            }
        }

        public double HOffSet
        {
            get
            {
                return hOffSet;
            }

            set
            {
                hOffSet = value;
            }
        }

        public double VoffSet
        {
            get
            {
                return voffSet;
            }

            set
            {
                voffSet = value;
            }
        }
    }
}
