﻿using RayTracing_ZQ.Base_ZQ;
using RayTracing_ZQ.Manager_ZQ;
using RayTracing_ZQ.Prefab;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 存放对象
    /// </summary>
    public class SceneManger:BaseMgr<SceneManger>
    {
        //物体
        private List<GeometryObject> _lstGeobj = new List<GeometryObject>();
        private List<MyObject> allObjets = new List<MyObject>();
        private Light pointLight;//点光源
        private Light ambientLight;//环境光源
        private Camera camera;//光源
        public SceneManger()
        {
            pointLight = new Light();
            pointLight.Name = "pointLight";
            camera = new Camera();
            camera.Name = "camera";
            ambientLight = new Light();
            ambientLight.Name = "ambientLight";
        }

        /// <summary>
        /// 创建世界
        /// </summary>
        /// <param name="theWorld"></param>
        public void Build()
        {
            Camera.Eye = new Point3D(0, 2, 8);//视线起点0, 4, 10
            PointLight.Pos = new Point3D(8, 20, -3);//光照3, 2, 2
            PointLight.LightColor  = new SColor(1, 1, 1);//光源强度0.84, 0.93, 0.94
            ambientLight.LightColor = new SColor(1, 1, 1);//环境光颜色0.07, 0.27, 0.58




            //Sphere sphere1 = new Sphere(new Point3D(3, 1, -4), 1);//生成圆-材质
            //Material mt1 = new Material(0.3, 0.8, 0.3, 500, new SColor(
            //1, 1, 1));//0.1, 0.1, 0.1
            //Texture texture1 = new Texture();
            //texture1.MyBitmap = new Bitmap(@"F:\Unity资源\Texture\timg2.jfif");
            //mt1.Texture = texture1;
            //sphere1.Material = mt1;
            //sphere1.Name = "sphere1";
            //AddObj(sphere1);

            Sphere sphere2 = new Sphere(new Point3D(0, 2, -4), 2);//生成圆-材质
            Material mt2 = new Material(0.3, 0.8, 0.3, 500, new SColor(
            1, 1, 1));//0, 0.5, 0.9
            Texture texture2 = new Texture();//F:\Unity资源\Texture\地球平面贴图材质\4096_earth.jpg;F:\软件工程\大三下\3D图形学\材质\材质\EarthHighRes.jpg；
            texture2.MyBitmap = new Bitmap(@"F:\Unity资源\Texture\地球平面贴图材质\4096_earth.jpg");
            mt2.Texture = texture2;
            sphere2.Material = mt2;
            sphere2.Name = "sphere2";
            AddObj(sphere2);

            //Sphere sphere3 = new Sphere(new Point3D(-6, 4, -4), 4);//生成圆-材质
            //Material mt3 = new Material(0.3, 0.8, 0.3, 200, new SColor(
            //1, 1, 1));//0.4, 0.6, 0.25
            //Texture texture3 = new Texture();
            //texture3.MyBitmap = new Bitmap(@"F:\Unity资源\Texture\timg.jfif");
            //mt3.Texture = texture3;
            //sphere3.Material = mt3;
            //sphere3.Name = "sphere3";
            //AddObj(sphere3);


            Sphere bigSphere = new Sphere(new Point3D(0, -101, -5.0), 100);//生成圆-材质
            Material bigMt = new Material(0.3, 0.7, 0.3, 500, new SColor(
            0, 0, 0.5));
            //Texture bigTexture = new Texture();
            //bigTexture.MyBitmap = new Bitmap(@"F:\Unity资源\Texture\aerial_grass_rock_2k_jpg\aerial_grass_rock_diff_2k.jpg");
            //bigMt.Texture = bigTexture;
            bigSphere.Material = bigMt;
            bigSphere.Name = "bigSphere";
            AddObj(bigSphere);

            Sphere SkySphere = new Sphere(new Point3D(0, 0, 0), 30);//生成圆-材质
            Material skyMt = new Material(1, 0.8, 0.3, 500, new SColor(
            1, 1, 1));
            Texture skyTexture = new Texture();
            skyTexture.MyBitmap = new Bitmap(@"F:\Unity资源\Texture\satara_night_no_lamps.jpg");
            skyMt.Texture = skyTexture;
            SkySphere.Material = skyMt;
            SkySphere.Name = "SkySphere";
            AddObj(SkySphere);

        }


        /// <summary>
        /// 获取最前面击中的点
        /// </summary>
        /// <param name="ray"></param>
        /// <returns></returns>
        public ShadeRec HitAll(Ray ray)
        {
            double tMin = 1e10;
            ShadeRec srResult = new ShadeRec();
            ShadeRec sr;
            for (int i = 0; i < LstGeobj.Count; i++)
            {
                if (LstGeobj[i].Hit(ray, out sr) && (sr.T < tMin))
                {
                    srResult = sr;
                    tMin = srResult.T;
                }
            }
            return srResult;

            //if (LstGeobj.Count == 0) return null;
            //ShadeRec sr = null;
            //ShadeRec tempsr = null;
            //for (int i = 0; i < LstGeobj.Count; i++)
            //{
            //    LstGeobj[i].Hit(ray, out tempsr);
            //    if (tempsr.IsHit)
            //    {
            //        if (sr != null)
            //        {
            //            if (sr.T > tempsr.T)
            //            {
            //                sr = tempsr;
            //            }
            //        }
            //        else
            //        {
            //            sr = tempsr;
            //        }
            //    }
            //}
            //if (sr != null)
            //    return sr;
            //else
            //    return tempsr;
        }

        /// <summary>
        /// 判断是否有球挡住
        /// </summary>
        /// <param name="ray"></param>
        /// <returns></returns>
        public bool ShadowHitAll(Ray ray)
        {
            for (int i = 0; i < LstGeobj.Count; i++)
            {
                if (LstGeobj[i].ShadowHit(ray))
                    return true;
            }
            return false;
        }


        /// <summary>
        /// 添加物体
        /// </summary>
        /// <param name="obj">物体</param>
        public void AddObj(GeometryObject obj)
        {
            _lstGeobj.Add(obj);
        }

        public List<GeometryObject> LstGeobj
        {
            get
            {
                return _lstGeobj;
            }

            set
            {
                _lstGeobj = value;
            }
        }

        internal Light PointLight
        {
            get
            {
                return pointLight;
            }

            set
            {
                pointLight = value;
            }
        }

        internal Camera Camera
        {
            get
            {
                return camera;
            }

            set
            {
                camera = value;
            }
        }

        internal Light AmbientLight
        {
            get
            {
                return ambientLight;
            }

            set
            {
                ambientLight = value;
            }
        }
    }
}
