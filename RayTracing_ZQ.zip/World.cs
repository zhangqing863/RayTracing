﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 存放对象
    /// </summary>
    public class World
    {
        //物体
        private List<GeometryObject> _lstGeobj = new List<GeometryObject>();
        public Point3D eye = new Point3D(0, 0, 4);//视线起点
        public Point3D light = new Point3D(-1, 2, -1);//光照
        public double ka = 0.5;//环境光
        public SColor Id = new SColor(1, 1, 1);//光源强度


        /// <summary>
        /// 获取最前面击中的点
        /// </summary>
        /// <param name="ray"></param>
        /// <returns></returns>
        public ShadeRec HitAll(Ray ray)
        {
            if (LstGeobj.Count == 0) return null;
            ShadeRec sr = null;
            ShadeRec tempsr = null;
            for (int i = 0; i < LstGeobj.Count; i++)
            {
                LstGeobj[i].Hit(ray, out tempsr);
                if(tempsr.IsHit)
                {
                    if(sr!=null)
                    {
                        if(sr.T>tempsr.T)
                        {
                            sr = tempsr;
                        }
                    }
                    else
                    {
                        sr = tempsr;
                    }
                }
            }
            if (sr != null)
                return sr;
            else
                return tempsr;
        }

        /// <summary>
        /// 判断是否有球挡住
        /// </summary>
        /// <param name="ray"></param>
        /// <returns></returns>
        public bool ShadowHitAll(Ray ray)
        {
            for (int i = 0; i < LstGeobj.Count; i++)
            {
                if (LstGeobj[i].ShadowHit(ray))
                    return true;
            }
            return false;
        }


        /// <summary>
        /// 添加物体
        /// </summary>
        /// <param name="obj">物体</param>
        public void AddObj(GeometryObject obj)
        {
            _lstGeobj.Add(obj);
        }

        public List<GeometryObject> LstGeobj
        {
            get
            {
                return _lstGeobj;
            }

            set
            {
                _lstGeobj = value;
            }
        }
    }
}
