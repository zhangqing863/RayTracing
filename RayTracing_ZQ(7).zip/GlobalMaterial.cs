﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    public abstract class GlobalMaterial
    {
        SColor attenuation;//颜色

        public SColor Attenuation
        {
            get
            {
                return attenuation;
            }

            set
            {
                attenuation = value;
            }
        }
        public GlobalMaterial(SColor a)
        {
            Attenuation = a;
        }

        /// <summary>
        /// 散射特性----漫发射，镜面反射
        /// </summary>
        /// <param name="rayIn">入射光线</param>
        /// <param name="sr">击中点信息</param>
        /// <param name="scattered">散射光线</param>
        /// <returns></returns>
        public abstract bool Scatter(Ray rayIn, ShadeRec sr, out Ray scattered);
    }

    class Lambertian : GlobalMaterial
    {
        public Lambertian(SColor clr):base(clr)
        {
        }
        //随机漫反射
        public override bool Scatter(Ray rayIn, ShadeRec sr, out Ray scattered)
        {
            Point3D target = sr.Hitpoint + sr.Normal + Vector3D.random_in_unit_sphere();
            scattered = new Ray(sr.Hitpoint, target - sr.Hitpoint);
            return true;
        }
    }


    class Metal : GlobalMaterial
    {
        public Metal(SColor clr) : base(clr)
        {
        }
        //镜面反射
        public override bool Scatter(Ray rayIn, ShadeRec sr, out Ray scattered)
        {
            Vector3D reflectedDir = GetReflectDir(rayIn.Direction, sr.Normal);
            reflectedDir.Normalize();
            scattered = new Ray(sr.Hitpoint, reflectedDir);
            return (scattered.Direction* sr.Normal) > 0;
        }

        //计算反射向量
        private Vector3D GetReflectDir(Vector3D v, Vector3D n)
        {
            v.Normalize();
            n.Normalize();
            return v - 2 * (v * n) * n;
        }
    }
}
