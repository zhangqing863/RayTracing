﻿using RayTracing_ZQ.Base_ZQ;
using RayTracing_ZQ.Prefab;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static RayTracing_ZQ.AVIWriter;

namespace RayTracing_ZQ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            unit();
        }
        private void unit()
        {
            SceneManger.GetInstance().Build();
            HierarchyMgr.GetInstance().AddHierarchyPanel(objFlpanel);
            targetTexture = new Texture();
            myCanvas = new Canvas(1920, 1080);
            txtWidth.Text = myCanvas.ResolutionWidth.ToString();
            txtHeight.Text = myCanvas.ResolutionHeight.ToString();
            GetAllRenderUI();
            //允许捕获对错误线程的调用
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        
        #region 属性
        Texture targetTexture;//目标贴图
        List<Bitmap> frames = new List<Bitmap>();//每一帧图片
        Canvas myCanvas;//分辨率 2560, 1440
        //FastBitmap fastBitmap = new FastBitmap(hRes,vRes);
        //用于控制渲染控件的Enable
        List<Control> renderUIs = new List<Control>();//渲染控件的列表
        string renderUIName = "render";//渲染控件的前缀或后缀

        #endregion


        #region 渲染逻辑
        /// <summary>
        /// 异步处理图像
        /// </summary>
        /// <param name="myCanvas">要处理的画布</param>
        /// <param name="theWorld">所在的场景</param>
        private void Render(object sender)
        {
            
            int trackbarValue = 0;
            if (renderRotateBar.InvokeRequired)
            {
                trackbarValue = renderRotateBar.Value;
            }
            Stopwatch sw = new Stopwatch();
            sw.Start();



            for (int i = 0; i < myCanvas.ResolutionWidth; i++)
            {
                for (int j = 0; j < myCanvas.ResolutionHeight; j++)
                {
                    //射线
                    //Point3D p = new Point3D(-2 + i * myCanvas.HOffSet, 2 - j * myCanvas.VoffSet, 2);
                    Point3D p = new Point3D(-2 + i * myCanvas.HOffSet, 3 - j * myCanvas.VoffSet, 6);
                    //Point3D p = new Point3D(-2 + i * step, 1 - j * step, 2);
                    Vector3D dir = p - SceneManger.GetInstance().Camera.Eye;
                    Ray ray = new Ray(SceneManger.GetInstance().Camera.Eye, dir);

                    ShadeRec sr;

                    sr = SceneManger.GetInstance().HitAll(ray);
                    //sphere.Hit(ray,out sr);//是否击中
                    if (sr.IsHit)
                    {
                        //交点到光源：入射光方向
                        Vector3D rayLight = (SceneManger.GetInstance().PointLight.Pos - sr.Hitpoint);
                        rayLight.Normalize();
                        //能否看到光源
                        Ray shadowRay = new Ray(sr.Hitpoint, rayLight);

                        //求取阴影光线与所有物体是否相加
                        if (!SceneManger.GetInstance().ShadowHitAll(shadowRay))
                        {
                            //R:反射光方向
                            Vector3D R = 2 * sr.Normal * (sr.Normal * rayLight) - rayLight;
                            R.Normalize();
                            Vector3D V = SceneManger.GetInstance().Camera.Eye - sr.Hitpoint/*p*/;
                            V.Normalize();
                            double VR = V * R;
                            double LN = rayLight * sr.Normal;
                            if (LN <= 0) LN = 0;
                            if (VR <= 0) VR = 0;

                            Material mat = sr.HitObjMat;

                            //Lambert漫反射 + Phong镜面反射
                            SColor lambdiff = SceneManger.GetInstance().AmbientLight.LightColor * mat.Ka;//环境光
                                                                                        //SColor sColor1 = mat.MatColor * theWorld.PointLight.Ka;//环境光
                            SColor Ildiff = SceneManger.GetInstance().PointLight.LightColor * mat.Kd * mat.MatColor * (LN); //方向光
                            SColor Ispec = SceneManger.GetInstance().PointLight.LightColor * mat.Ks * mat.MatColor * Math.Pow(VR, mat.Ns); //Phong镜面反射

                            SColor Idiffuse = lambdiff + Ildiff + Ispec;
                            //光照颜色
                            Color lColor = Idiffuse.GetRGB255Color();

                            
                            //如果设置了纹理进行融合
                            if (sr.HitObjMat.Texture != null)
                            {
                                //旋转
                                double theta = Math.PI * trackbarValue / 180.0;
                                double x = sr.Normal.X * Math.Cos(theta) + sr.Normal.Z * Math.Sin(theta);
                                double z = -sr.Normal.X * Math.Sin(theta) + sr.Normal.Z * Math.Cos(theta);
                                //旋转
                                sr.Normal.X = x;
                                sr.Normal.Z = z;

                                Color tColor = sr.HitObjMat.Texture.GetColor(sr);
                                lColor = Color.FromArgb(
                                    (int)(tColor.R * ((double)lColor.R / 255)),
                                    (int)(tColor.G * ((double)lColor.G / 255)),
                                    (int)(tColor.B * ((double)lColor.B / 255))
                                    );
                            }

                            myCanvas.MyBitmap.SetPixel(i, j, lColor);
                            //fastBitmap.SetArgbByte(i, j, Idiffuse);
                        }
                        else
                        {
                            myCanvas.MyBitmap.SetPixel(i, j, Color.FromArgb(25, 32, 34));
                        }
                    }
                    else
                    {
                        myCanvas.MyBitmap.SetPixel(i, j, Color.FromArgb(44, 44, 62) /*Color.FromArgb(45, 52, 54)*/);
                        //fastBitmap.SetArgbByte(i, j, Color.Black);
                    }
                }
                //执行委托
                this.Invoke(new ShowProgressDelegate(ShowProgress), new object[] { myCanvas.ResolutionWidth, i + 1,sw.Elapsed.ToString()});

            }

            //fastBitmap.FastBitmapSetGradient();
            sw.Stop();

            //控件赋值
            pic.BackgroundImage = myCanvas.MyBitmap.GetThumbnailImage(pic.Width, pic.Height, null, IntPtr.Zero);
            //pic.BackgroundImage = fastBitmap.bitmap.GetThumbnailImage(pic.Width, pic.Height, null, IntPtr.Zero);
            //lblTime.Text = sw.Elapsed.ToString();

            frames.Add(myCanvas.MyBitmap);
        }

        /// <summary>
        /// 同步处理图像
        /// </summary>
        private void Render()
        {
            for (int i = 0; i < myCanvas.ResolutionWidth; i++)
            {
                for (int j = 0; j < myCanvas.ResolutionHeight; j++)
                {
                    //射线
                    //Point3D p = new Point3D(-2 + i * myCanvas.HOffSet, 2 - j * myCanvas.VoffSet, 2);
                    Point3D p = new Point3D(-2 + i * myCanvas.HOffSet, 3 - j * myCanvas.VoffSet, 6);
                    //Point3D p = new Point3D(-2 + i * step, 1 - j * step, 2);
                    Vector3D dir = p - SceneManger.GetInstance().Camera.Eye;
                    Ray ray = new Ray(SceneManger.GetInstance().Camera.Eye, dir);

                    ShadeRec sr;

                    sr = SceneManger.GetInstance().HitAll(ray);
                    //sphere.Hit(ray,out sr);//是否击中
                    if (sr.IsHit)
                    {
                        //交点到光源：入射光方向
                        Vector3D rayLight = (SceneManger.GetInstance().PointLight.Pos - sr.Hitpoint);
                        rayLight.Normalize();
                        //能否看到光源
                        Ray shadowRay = new Ray(sr.Hitpoint, rayLight);

                        //求取阴影光线与所有物体是否相加
                        if (!SceneManger.GetInstance().ShadowHitAll(shadowRay))
                        {
                            //R:反射光方向
                            Vector3D R = 2 * sr.Normal * (sr.Normal * rayLight) - rayLight;
                            R.Normalize();
                            Vector3D V = SceneManger.GetInstance().Camera.Eye - sr.Hitpoint/*p*/;
                            V.Normalize();
                            double VR = V * R;
                            double LN = rayLight * sr.Normal;
                            if (LN <= 0) LN = 0;
                            if (VR <= 0) VR = 0;

                            Material mat = sr.HitObjMat;

                            //Lambert漫反射 + Phong镜面反射
                            SColor lambdiff = SceneManger.GetInstance().AmbientLight.LightColor * mat.Ka;//环境光
                                                                                        //SColor sColor1 = mat.MatColor * theWorld.PointLight.Ka;//环境光
                            SColor Ildiff = SceneManger.GetInstance().PointLight.LightColor * mat.Kd * mat.MatColor * (LN); //方向光
                            SColor Ispec = SceneManger.GetInstance().PointLight.LightColor * mat.Ks * mat.MatColor * Math.Pow(VR, mat.Ns); //Phong镜面反射

                            SColor Idiffuse = lambdiff + Ildiff + Ispec;
                            //光照颜色
                            Color lColor = Idiffuse.GetRGB255Color();


                            //如果设置了纹理进行融合
                            if (sr.HitObjMat.Texture != null)
                            {
                                //旋转
                                double theta = Math.PI * renderRotateBar.Value / 180.0;
                                double x = sr.Normal.X * Math.Cos(theta) + sr.Normal.Z * Math.Sin(theta);
                                double z = -sr.Normal.X * Math.Sin(theta) + sr.Normal.Z * Math.Cos(theta);
                                //旋转
                                sr.Normal.X = x;
                                sr.Normal.Z = z;

                                Color tColor = sr.HitObjMat.Texture.GetColor(sr);
                                lColor = Color.FromArgb(
                                    (int)(tColor.R * ((double)lColor.R / 255)),
                                    (int)(tColor.G * ((double)lColor.G / 255)),
                                    (int)(tColor.B * ((double)lColor.B / 255))
                                    );
                            }

                            myCanvas.MyBitmap.SetPixel(i, j, lColor);
                            //fastBitmap.SetArgbByte(i, j, Idiffuse);
                        }
                        else
                        {
                            myCanvas.MyBitmap.SetPixel(i, j, Color.FromArgb(25, 32, 34));
                        }
                    }
                    else
                    {
                        myCanvas.MyBitmap.SetPixel(i, j, Color.FromArgb(44, 44, 62) /*Color.FromArgb(45, 52, 54)*/);
                        //fastBitmap.SetArgbByte(i, j, Color.Black);
                    }
                }
            }
            //fastBitmap.FastBitmapSetGradient();
        }

        #endregion



        #region 控件事件

        private void renderBtn_Click(object sender, EventArgs e)
        {
            //theWorld.LstGeobj[0].Material.Texture = targetTexture;

            //texture3.MyBitmap = new Bitmap(@"F:\Unity资源\Texture\aerial_grass_rock_2k_jpg\aerial_grass_rock_diff_2k.jpg");
            //theWorld.LstGeobj[1].Material.Texture = texture3;
            RenderAsync(sender);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (HierarchyMgr.GetInstance().currentLabel == null)
            {
                MessageBox.Show("未选择几何体进行贴图更换!!!", "警告", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Label label = HierarchyMgr.GetInstance().currentLabel;
            if (HierarchyMgr.GetInstance().lblObjDic[label.Name] is GeometryObject)
            {
                Texture texture = new Texture();
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.ShowDialog();
                if (ofd.FileName != "")
                {
                    texture.MyBitmap = new Bitmap(ofd.FileName);
                    (HierarchyMgr.GetInstance().lblObjDic[label.Name] as GeometryObject).Material.Texture = texture;
                }
            }
            else
            {
                MessageBox.Show("请选择几何体进行贴图更换!!!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }


        private void btnImport2AVI_Click(object sender, EventArgs e)
        {
            ImportAVI();
        }
        
        
        private void renderRotateBar_MouseUp(object sender, MouseEventArgs e)
        {
            RenderAsync(sender);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //关闭窗体时释放所有线程
            System.Environment.Exit(0);
        }

        /// <summary>
        /// 定时清理缓存
        /// </summary>
        private void timer1_Tick(object sender, EventArgs e)
        {
            ClearMemory();
        }


        private void txtWidth_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsNumber(e.KeyChar) && e.KeyChar != (char)8)
            {
                e.Handled = true;
            }
        }
        #region 修改分辨率
        ////判断是否更改了分辨率的值
        //bool isChangeResoultion = false;
        private void txtWidth_TextChanged(object sender, EventArgs e)
        {
            RstioGpBox.MouseLeave += RstioGpBox_Leave;
        }

        private void RstioGpBox_Leave(object sender, EventArgs e)
        {
            //如果更改了分辨率则在鼠标离开此面板时生效并修改全局下的画板
            if (!txtWidth.Text.StartsWith("0") && !txtHeight.Text.StartsWith("0"))
            {
                int width = int.Parse(txtWidth.Text);
                int height = int.Parse(txtHeight.Text);
                if (myCanvas.ResolutionWidth != width || myCanvas.ResolutionHeight != height)
                {
                    myCanvas = new Canvas(width, height);
                }
            }
            else
            {
                txtWidth.Text = myCanvas.ResolutionWidth.ToString();
                txtHeight.Text = myCanvas.ResolutionHeight.ToString();
            }
        }
        #endregion
        #endregion


        #region 异步渲染过程
        private void RenderAsync(object sender)
        {
            ParameterizedThreadStart start = new ParameterizedThreadStart(Render);
            Thread progressThread = new Thread(start);
            progressThread.IsBackground = true;
            progressThread.Start();
            CloseRenderUI();
        }
        // 定义委托，异步调用
        delegate void ShowProgressDelegate(int totalStep, int currentStep, string currentTime);
        /// <summary>
        /// 要刷新的控件方法
        /// </summary>
        private void ShowProgress(int totalStep, int currentStep, string currentTime)
        {
            renderProgressBar.Maximum = totalStep;
            renderProgressBar.Value = currentStep;
            lblTime.Text = "当前渲染时间：" + currentTime;
            if (renderProgressBar.Value == renderProgressBar.Maximum)
            {
                OpenRenderUI();
            }
        }

        #region 开放-闭合渲染控件
        private void GetAllRenderUI()
        {
            foreach(Control item in this.Controls)
            {
                if(item.Name.Contains(renderUIName))
                {
                    renderUIs.Add(item);
                }
            }
        }
        private void OpenRenderUI()
        {
            foreach (Control item in renderUIs)
            {
                item.Enabled = true;
            }
        }

        private void CloseRenderUI()
        {
            foreach (Control item in renderUIs)
            {
                item.Enabled = false;
            }
        }
        #endregion

        #endregion

        #region 导出
        /// <summary>
        /// 将渲染的图片合成并导出为AVI文件
        /// </summary>
        private void ImportAVI()
        {
            try
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "视频文件|*.avi";
                sfd.ShowDialog();
                AVIWriter aviWriter = new AVIWriter();
                Bitmap avi_frame = aviWriter.Create(sfd.FileName, 30, 1920, 1080);
                int rotateAngle = 360;
                for (int i = 0; i <= rotateAngle; i += 1)
                {
                    renderRotateBar.Value = i;
                    Render();
                    Bitmap bitmap = new Bitmap(myCanvas.MyBitmap);
                    bitmap.RotateFlip(RotateFlipType.Rotate180FlipX);
                    aviWriter.LoadFrame(bitmap);
                    aviWriter.AddFrame();
                    bitmap.Dispose();
                }
                //释放资源
                aviWriter.Close();
                avi_frame.Dispose();

                MessageBox.Show("转换完毕");
            }
            catch(AviException e)
            {
                MessageBox.Show("已退出当前任务", "消息", MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }
        #endregion

        #region 内存回收
        [DllImport("kernel32.dll", EntryPoint = "SetProcessWorkingSetSize")]
        public static extern int SetProcessWorkingSetSize(IntPtr process, int minSize, int maxSize);
        /// <summary>
        /// 释放内存
        /// </summary>
        public static void ClearMemory()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            if (Environment.OSVersion.Platform == PlatformID.Win32NT)
            {
                Form1.SetProcessWorkingSetSize(System.Diagnostics.Process.GetCurrentProcess().Handle, -1, -1);
            }
        }




        #endregion

        
    }

}
