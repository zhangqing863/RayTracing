﻿namespace RayTracing_ZQ
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.renderBtn = new System.Windows.Forms.Button();
            this.pic = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.renderRotateBar = new System.Windows.Forms.TrackBar();
            this.btnImport2AVI = new System.Windows.Forms.Button();
            this.renderProgressBar = new System.Windows.Forms.ProgressBar();
            this.label3 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.objGpBox = new System.Windows.Forms.GroupBox();
            this.TFGpBox = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtTFrz = new System.Windows.Forms.TextBox();
            this.txtTFry = new System.Windows.Forms.TextBox();
            this.txtTFrx = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTFtz = new System.Windows.Forms.TextBox();
            this.txtTFty = new System.Windows.Forms.TextBox();
            this.txtTFtx = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTFsz = new System.Windows.Forms.TextBox();
            this.txtTFsy = new System.Windows.Forms.TextBox();
            this.txtTFsx = new System.Windows.Forms.TextBox();
            this.RstioGpBox = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.objFlpanel = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.renderRotateBar)).BeginInit();
            this.objGpBox.SuspendLayout();
            this.TFGpBox.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.RstioGpBox.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // renderBtn
            // 
            this.renderBtn.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.renderBtn.Location = new System.Drawing.Point(68, 339);
            this.renderBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.renderBtn.Name = "renderBtn";
            this.renderBtn.Size = new System.Drawing.Size(197, 102);
            this.renderBtn.TabIndex = 0;
            this.renderBtn.Text = "渲染";
            this.renderBtn.UseVisualStyleBackColor = true;
            this.renderBtn.Click += new System.EventHandler(this.renderBtn_Click);
            // 
            // pic
            // 
            this.pic.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.pic.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic.Location = new System.Drawing.Point(9, 30);
            this.pic.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pic.Name = "pic";
            this.pic.Size = new System.Drawing.Size(1066, 501);
            this.pic.TabIndex = 1;
            this.pic.TabStop = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(332, 54);
            this.label1.TabIndex = 2;
            this.label1.Text = "张庆_201731062511";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTime
            // 
            this.lblTime.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lblTime.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.lblTime.Location = new System.Drawing.Point(7, 532);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(1068, 35);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "渲染时间";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(68, 140);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(197, 102);
            this.button2.TabIndex = 0;
            this.button2.Text = "设置纹理";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // renderRotateBar
            // 
            this.renderRotateBar.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.renderRotateBar.Location = new System.Drawing.Point(415, 82);
            this.renderRotateBar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.renderRotateBar.Maximum = 360;
            this.renderRotateBar.Name = "renderRotateBar";
            this.renderRotateBar.Size = new System.Drawing.Size(1011, 56);
            this.renderRotateBar.TabIndex = 4;
            this.renderRotateBar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.renderRotateBar_MouseUp);
            // 
            // btnImport2AVI
            // 
            this.btnImport2AVI.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImport2AVI.Location = new System.Drawing.Point(68, 554);
            this.btnImport2AVI.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnImport2AVI.Name = "btnImport2AVI";
            this.btnImport2AVI.Size = new System.Drawing.Size(197, 102);
            this.btnImport2AVI.TabIndex = 0;
            this.btnImport2AVI.Text = "导出AVI";
            this.btnImport2AVI.UseVisualStyleBackColor = true;
            this.btnImport2AVI.Click += new System.EventHandler(this.btnImport2AVI_Click);
            // 
            // renderProgressBar
            // 
            this.renderProgressBar.Location = new System.Drawing.Point(9, 20);
            this.renderProgressBar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.renderProgressBar.Name = "renderProgressBar";
            this.renderProgressBar.Size = new System.Drawing.Size(1067, 10);
            this.renderProgressBar.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.label3.Location = new System.Drawing.Point(343, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 56);
            this.label3.TabIndex = 2;
            this.label3.Text = "旋转";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // objGpBox
            // 
            this.objGpBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.objGpBox.BackColor = System.Drawing.Color.Transparent;
            this.objGpBox.Controls.Add(this.TFGpBox);
            this.objGpBox.Controls.Add(this.RstioGpBox);
            this.objGpBox.Controls.Add(this.objFlpanel);
            this.objGpBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.objGpBox.ForeColor = System.Drawing.Color.White;
            this.objGpBox.Location = new System.Drawing.Point(1448, 84);
            this.objGpBox.Margin = new System.Windows.Forms.Padding(4);
            this.objGpBox.Name = "objGpBox";
            this.objGpBox.Padding = new System.Windows.Forms.Padding(4);
            this.objGpBox.Size = new System.Drawing.Size(319, 572);
            this.objGpBox.TabIndex = 6;
            this.objGpBox.TabStop = false;
            this.objGpBox.Text = "Object";
            // 
            // TFGpBox
            // 
            this.TFGpBox.Controls.Add(this.groupBox4);
            this.TFGpBox.Controls.Add(this.groupBox3);
            this.TFGpBox.Controls.Add(this.groupBox2);
            this.TFGpBox.Enabled = false;
            this.TFGpBox.ForeColor = System.Drawing.Color.White;
            this.TFGpBox.Location = new System.Drawing.Point(25, 104);
            this.TFGpBox.Name = "TFGpBox";
            this.TFGpBox.Size = new System.Drawing.Size(267, 208);
            this.TFGpBox.TabIndex = 2;
            this.TFGpBox.TabStop = false;
            this.TFGpBox.Text = "Transform";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.txtTFrz);
            this.groupBox4.Controls.Add(this.txtTFry);
            this.groupBox4.Controls.Add(this.txtTFrx);
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(12, 141);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(244, 54);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Rotate";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(169, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "Z";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(89, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 20);
            this.label12.TabIndex = 1;
            this.label12.Text = "Y";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 20);
            this.label13.TabIndex = 1;
            this.label13.Text = "X";
            // 
            // txtTFrz
            // 
            this.txtTFrz.Location = new System.Drawing.Point(191, 21);
            this.txtTFrz.Name = "txtTFrz";
            this.txtTFrz.Size = new System.Drawing.Size(47, 27);
            this.txtTFrz.TabIndex = 0;
            this.txtTFrz.TextChanged += new System.EventHandler(this.txtTFsx_TextChanged);
            this.txtTFrz.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // txtTFry
            // 
            this.txtTFry.Location = new System.Drawing.Point(111, 21);
            this.txtTFry.Name = "txtTFry";
            this.txtTFry.Size = new System.Drawing.Size(47, 27);
            this.txtTFry.TabIndex = 0;
            this.txtTFry.TextChanged += new System.EventHandler(this.txtTFsx_TextChanged);
            this.txtTFry.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // txtTFrx
            // 
            this.txtTFrx.Location = new System.Drawing.Point(31, 21);
            this.txtTFrx.Name = "txtTFrx";
            this.txtTFrx.Size = new System.Drawing.Size(47, 27);
            this.txtTFrx.TabIndex = 0;
            this.txtTFrx.TextChanged += new System.EventHandler(this.txtTFsx_TextChanged);
            this.txtTFrx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.txtTFtz);
            this.groupBox3.Controls.Add(this.txtTFty);
            this.groupBox3.Controls.Add(this.txtTFtx);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(12, 87);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(244, 54);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Translate";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(169, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 20);
            this.label8.TabIndex = 1;
            this.label8.Text = "Z";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(89, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(17, 20);
            this.label9.TabIndex = 1;
            this.label9.Text = "Y";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(18, 20);
            this.label10.TabIndex = 1;
            this.label10.Text = "X";
            // 
            // txtTFtz
            // 
            this.txtTFtz.Location = new System.Drawing.Point(191, 21);
            this.txtTFtz.Name = "txtTFtz";
            this.txtTFtz.Size = new System.Drawing.Size(47, 27);
            this.txtTFtz.TabIndex = 0;
            this.txtTFtz.TextChanged += new System.EventHandler(this.txtTFsx_TextChanged);
            this.txtTFtz.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // txtTFty
            // 
            this.txtTFty.Location = new System.Drawing.Point(111, 21);
            this.txtTFty.Name = "txtTFty";
            this.txtTFty.Size = new System.Drawing.Size(47, 27);
            this.txtTFty.TabIndex = 0;
            this.txtTFty.TextChanged += new System.EventHandler(this.txtTFsx_TextChanged);
            this.txtTFty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // txtTFtx
            // 
            this.txtTFtx.Location = new System.Drawing.Point(31, 21);
            this.txtTFtx.Name = "txtTFtx";
            this.txtTFtx.Size = new System.Drawing.Size(47, 27);
            this.txtTFtx.TabIndex = 0;
            this.txtTFtx.TextChanged += new System.EventHandler(this.txtTFsx_TextChanged);
            this.txtTFtx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtTFsz);
            this.groupBox2.Controls.Add(this.txtTFsy);
            this.groupBox2.Controls.Add(this.txtTFsx);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(12, 27);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(244, 54);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Scale";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(169, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 20);
            this.label7.TabIndex = 1;
            this.label7.Text = "Z";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(89, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 20);
            this.label6.TabIndex = 1;
            this.label6.Text = "Y";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "X";
            // 
            // txtTFsz
            // 
            this.txtTFsz.Location = new System.Drawing.Point(191, 21);
            this.txtTFsz.Name = "txtTFsz";
            this.txtTFsz.Size = new System.Drawing.Size(47, 27);
            this.txtTFsz.TabIndex = 0;
            this.txtTFsz.TextChanged += new System.EventHandler(this.txtTFsx_TextChanged);
            this.txtTFsz.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // txtTFsy
            // 
            this.txtTFsy.Location = new System.Drawing.Point(111, 21);
            this.txtTFsy.Name = "txtTFsy";
            this.txtTFsy.Size = new System.Drawing.Size(47, 27);
            this.txtTFsy.TabIndex = 0;
            this.txtTFsy.TextChanged += new System.EventHandler(this.txtTFsx_TextChanged);
            this.txtTFsy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // txtTFsx
            // 
            this.txtTFsx.Location = new System.Drawing.Point(31, 21);
            this.txtTFsx.Name = "txtTFsx";
            this.txtTFsx.Size = new System.Drawing.Size(47, 27);
            this.txtTFsx.TabIndex = 0;
            this.txtTFsx.TextChanged += new System.EventHandler(this.txtTFsx_TextChanged);
            this.txtTFsx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // RstioGpBox
            // 
            this.RstioGpBox.Controls.Add(this.label4);
            this.RstioGpBox.Controls.Add(this.label2);
            this.RstioGpBox.Controls.Add(this.txtHeight);
            this.RstioGpBox.Controls.Add(this.txtWidth);
            this.RstioGpBox.Font = new System.Drawing.Font("Segoe UI Symbol", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RstioGpBox.ForeColor = System.Drawing.Color.White;
            this.RstioGpBox.Location = new System.Drawing.Point(25, 23);
            this.RstioGpBox.Margin = new System.Windows.Forms.Padding(4);
            this.RstioGpBox.Name = "RstioGpBox";
            this.RstioGpBox.Padding = new System.Windows.Forms.Padding(4);
            this.RstioGpBox.Size = new System.Drawing.Size(267, 74);
            this.RstioGpBox.TabIndex = 1;
            this.RstioGpBox.TabStop = false;
            this.RstioGpBox.Text = "Resolution";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI Symbol", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(168, 22);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Height";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI Symbol", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 22);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Width";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(171, 41);
            this.txtHeight.Margin = new System.Windows.Forms.Padding(4);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(87, 27);
            this.txtHeight.TabIndex = 0;
            this.txtHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtHeight.TextChanged += new System.EventHandler(this.txtWidth_TextChanged);
            this.txtHeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(8, 41);
            this.txtWidth.Margin = new System.Windows.Forms.Padding(4);
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(87, 27);
            this.txtWidth.TabIndex = 0;
            this.txtWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtWidth.TextChanged += new System.EventHandler(this.txtWidth_TextChanged);
            this.txtWidth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // objFlpanel
            // 
            this.objFlpanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.objFlpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.objFlpanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.objFlpanel.Location = new System.Drawing.Point(25, 331);
            this.objFlpanel.Margin = new System.Windows.Forms.Padding(4);
            this.objFlpanel.Name = "objFlpanel";
            this.objFlpanel.Size = new System.Drawing.Size(267, 223);
            this.objFlpanel.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panel1.Controls.Add(this.pic);
            this.panel1.Controls.Add(this.lblTime);
            this.panel1.Controls.Add(this.renderProgressBar);
            this.panel1.Location = new System.Drawing.Point(343, 124);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1085, 578);
            this.panel1.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(1783, 758);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.objGpBox);
            this.Controls.Add(this.renderRotateBar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnImport2AVI);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.renderBtn);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "张庆";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.renderRotateBar)).EndInit();
            this.objGpBox.ResumeLayout(false);
            this.TFGpBox.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.RstioGpBox.ResumeLayout(false);
            this.RstioGpBox.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button renderBtn;
        private System.Windows.Forms.PictureBox pic;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TrackBar renderRotateBar;
        private System.Windows.Forms.Button btnImport2AVI;
        private System.Windows.Forms.ProgressBar renderProgressBar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox objGpBox;
        private System.Windows.Forms.FlowLayoutPanel objFlpanel;
        private System.Windows.Forms.GroupBox RstioGpBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox TFGpBox;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtTFrz;
        private System.Windows.Forms.TextBox txtTFry;
        private System.Windows.Forms.TextBox txtTFrx;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTFtz;
        private System.Windows.Forms.TextBox txtTFty;
        private System.Windows.Forms.TextBox txtTFtx;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTFsz;
        private System.Windows.Forms.TextBox txtTFsy;
        private System.Windows.Forms.TextBox txtTFsx;
    }
}

