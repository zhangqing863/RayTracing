﻿using RayTracing_ZQ.Base_ZQ;
using RayTracing_ZQ.Manager_ZQ;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RayTracing_ZQ
{
    class HierarchyMgr : BaseMgr<HierarchyMgr>
    {
        public Dictionary<string, MyObject> lblObjDic = new Dictionary<string, MyObject>();
        public List<MyObject> allObjs = new List<MyObject>();
        private FlowLayoutPanel panel;
        public Label currentLabel;
        private Color
            lblColor = Color.FromArgb(52, 73, 94),
            lblClickColor = Color.FromArgb(52, 152, 219),
            lblForeColor = Color.FromArgb(200, 200, 200),
            lblClickForeColor = Color.White;
        public void AddHierarchyPanel(FlowLayoutPanel panel)
        {
            this.panel = panel;
            foreach (MyObject obj in allObjs)
            {
                AddObjLabel(obj.Name, obj);
            }
        }





        /// <summary>
        /// 通过传入物体名称和物体创建label
        /// </summary>
        /// <param name="name"></param>
        public void AddObjLabel(string name,MyObject obj)
        {
            lblObjDic.Add(name, obj);
            Label label = new Label();
            LabelUnit(name, label);
            panel.Controls.Add(label);
        }
        /// <summary>
        /// label参数设置
        /// </summary>
        /// <param name="name"></param>
        /// <param name="label"></param>
        private void LabelUnit(string name, Label label)
        {
            label.Name = name;
            label.BackColor = lblColor;
            label.AutoSize = false;
            label.Width = panel.Width;
            label.ForeColor = lblForeColor;
            label.Margin = new Padding(0, 0, 0, 1);
            label.Text = name;
            label.TextAlign = ContentAlignment.MiddleCenter;
            label.Click += LabelClick;
        }

        private void LabelClick(object sender,EventArgs args)
        {
            if(currentLabel!=null)
            {
                currentLabel.BackColor = lblColor;
                currentLabel.ForeColor = lblForeColor;
            }
            currentLabel = (sender as Label);
            currentLabel.BackColor = lblClickColor;
            currentLabel.ForeColor = lblClickForeColor;
        }
    }
}
