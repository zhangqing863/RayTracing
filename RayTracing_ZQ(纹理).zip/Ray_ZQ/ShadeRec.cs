﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 光线射击信息
    /// </summary>
    public class ShadeRec
    {
        private bool _isHit;//是否击中
        private Point3D _hitpoint;//击中点
        private Vector3D _normal;//击中点法线
        private Material _hitObjMat;//击中物体材质
        private GeometryObject geometry;//击中物体
        private GlobalMaterial _hitObjGlobalMat;//击中物体全局材质
        private double _t;//获取距离摄像机前方并离摄像机最近的t
        private double _u, _v;//击中点的uv信息

        public bool IsHit
        {
            get
            {
                return _isHit;
            }

            set
            {
                _isHit = value;
            }
        }

        public double T
        {
            get
            {
                return _t;
            }

            set
            {
                _t = value;
            }
        }

        public GeometryObject Geometry
        {
            get
            {
                return geometry;
            }

            set
            {
                geometry = value;
            }
        }

        public double U
        {
            get
            {
                return _u;
            }

            set
            {
                _u = value;
            }
        }

        public double V
        {
            get
            {
                return _v;
            }

            set
            {
                _v = value;
            }
        }

        internal Point3D HitPoint
        {
            get
            {
                return _hitpoint;
            }

            set
            {
                _hitpoint = value;
            }
        }

        internal Vector3D Normal
        {
            get
            {
                return _normal;
            }

            set
            {
                _normal = value;
            }
        }

        internal Material HitObjMat
        {
            get
            {
                return _hitObjMat;
            }

            set
            {
                _hitObjMat = value;
            }
        }

        internal GlobalMaterial HitObjGlobalMat
        {
            get
            {
                return _hitObjGlobalMat;
            }

            set
            {
                _hitObjGlobalMat = value;
            }
        }
    }
}
