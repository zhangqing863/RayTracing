﻿using RayTracing_ZQ.Base_ZQ;
using RayTracing_ZQ.Manager_ZQ;
using RayTracing_ZQ.Prefab;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace RayTracing_ZQ
{
    public class Scene
    {
        //物体
        private List<GeometryObject> _lstGeobj = new List<GeometryObject>();
        private List<MyObject> allObjets = new List<MyObject>();
        private Light pointLight;//点光源
        private Light ambientLight;//环境光源
        private Camera camera;//光源
        public Scene()
        {
            pointLight = new Light();
            pointLight.Name = "pointLight";
            camera = new Camera();
            camera.Name = "camera";
            ambientLight = new Light();
            ambientLight.Name = "ambientLight";
        }

        /// <summary>
        /// 创建世界
        /// </summary>
        /// <param name="theWorld"></param>
        public void Build()
        {
            Camera.Eye = new Point3D(0, 0, 0); ;//视线起点0, 4, 10
            PointLight.Pos = new Point3D(8, 20, -3);//光照3, 2, 2
            PointLight.LightColor = new SColor(1, 1, 1);//光源强度0.84, 0.93, 0.94
            ambientLight.LightColor = new SColor(1, 1, 1);//环境光颜色0.07, 0.27, 0.58

        }


        /// <summary>
        /// 获取最前面击中的点
        /// </summary>
        /// <param name="ray"></param>
        /// <returns></returns>
        public ShadeRec HitAll(Ray ray)
        {
            double tMin = 1e10;
            ShadeRec srResult = new ShadeRec();
            ShadeRec sr;
            for (int i = 0; i < LstGeobj.Count; i++)
            {
                if (LstGeobj[i].Hit(ray, out sr) && (sr.T < tMin))
                {
                    srResult = sr;
                    tMin = srResult.T;
                }
            }
            return srResult;
        }

        /// <summary>
        /// 判断是否有球挡住
        /// </summary>
        /// <param name="ray"></param>
        /// <returns></returns>
        public bool ShadowHitAll(Ray ray)
        {
            for (int i = 0; i < LstGeobj.Count; i++)
            {
                if (LstGeobj[i].ShadowHit(ray))
                    return true;
            }
            return false;
        }


            /// <summary>
            /// 添加物体
            /// </summary>
            /// <param name="obj">物体</param>
            public void AddObj(GeometryObject obj)
            {
                _lstGeobj.Add(obj);
            }

        public List<GeometryObject> LstGeobj
        {
            get
            {
                return _lstGeobj;
            }

            set
            {
                _lstGeobj = value;
            }
        }

        internal Light PointLight
        {
            get
            {
                return pointLight;
            }

            set
            {
                pointLight = value;
            }
        }

        internal Camera Camera
        {
            get
            {
                return camera;
            }

            set
            {
                camera = value;
            }
        }

        internal Light AmbientLight
        {
            get
            {
                return ambientLight;
            }

            set
            {
                ambientLight = value;
            }
        }
    }
}



