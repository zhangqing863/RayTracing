﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ.Base_ZQ
{
    class Transform
    {
        private MyMatrix pos;
        private MyMatrix scale;
        private MyMatrix rotate;

        internal MyMatrix Pos
        {
            get
            {
                return pos;
            }

            set
            {
                pos = value;
            }
        }

        internal MyMatrix Scale
        {
            get
            {
                return scale;
            }

            set
            {
                scale = value;
            }
        }

        internal MyMatrix Rotate
        {
            get
            {
                return rotate;
            }

            set
            {
                rotate = value;
            }
        }

        public Transform(MyMatrix pos, MyMatrix scale, MyMatrix rotate)
        {
            this.Pos = pos;
            this.Scale = scale;
            this.Rotate = rotate;
        }
        public void ScaleTF(double sx, double sy, double sz)
        {
            Scale.Scale(sx, sy, sz);
        }
        public void Translate(double tx, double ty, double tz)
        {
            Pos.Scale(tx, ty, tz);
        }

        public void RotateAtX(double angle)
        {
            Rotate.RotateAtX(angle);
        }
        public void RotateAtY(double angle)
        {
            Rotate.RotateAtY(angle);
        }
        public void RotateAtZ(double angle)
        {
            Rotate.RotateAtZ(angle);
        }
    }
}
