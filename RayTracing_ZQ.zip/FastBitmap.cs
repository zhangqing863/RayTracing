﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 利用lockbits方法快速对Bitmap进行读写
    /// </summary>
    class FastBitmap
    {
        public int width;
        public int height;
        public  Bitmap bitmap;//进行操控的Bitmap
        public Byte[] rgbValues;//进行记录颜色数据的数组

        public int Width
        {
            get
            {
                return width;
            }

            set
            {
                width = value;
            }
        }

        public int Height
        {
            get
            {
                return height;
            }

            set
            {
                height = value;
            }
        }



        public FastBitmap(int w,int h)
        {
            Width = w;
            Height = h;
            bitmap = new Bitmap(Width, Height);
            rgbValues = new byte[Width * Height * 4];
        }
        public FastBitmap(Bitmap bitmap)
        {
            Width = bitmap.Width;
            Height = bitmap.Height;
            this.bitmap = bitmap;
            rgbValues = new byte[Width * Height * 4];
        }

        /// <summary>
        /// 设置读入内存的byte数组的值
        /// </summary>
        /// <param name="x">像素点x轴</param>
        /// <param name="y">像素点y轴</param>
        /// <param name="color">颜色</param>
        public void SetArgbByte(int x, int y, Color color)
        {
            int[] rgb = new int[3];
            rgb = RGB(color.ToArgb());
            rgbValues[(y) * 4 * Width + x * 4] = (byte)rgb[0];
            rgbValues[(y) * 4 * Width + x * 4 + 1] = (byte)rgb[1];
            rgbValues[(y) * 4 * Width + x * 4 + 2] = (byte)rgb[2];
            rgbValues[(y) * 4 * Width + x * 4 + 3] = (byte)(255);
        }
        public void SetArgbByte(int x, int y, SColor color)
        {
            rgbValues[(y) * 4 * Width + x * 4] = (byte)(int)(color.R*255);
            rgbValues[(y) * 4 * Width + x * 4 + 1] = (byte)(int)(color.G * 255);
            rgbValues[(y) * 4 * Width + x * 4 + 2] = (byte)(int)(color.B * 255);
            rgbValues[(y) * 4 * Width + x * 4 + 3] = (byte)(255);
        }
        /// <summary>
        ///  利用内存去对Bitmap进行快速操作
        /// </summary>
        public void FastBitmapSetGradient()
        {
            // 锁定位图
            Rectangle rect = new Rectangle(0, 0, Width, Height);
            BitmapData bmpData =
                bitmap.LockBits(rect, ImageLockMode.ReadWrite,
                bitmap.PixelFormat);

            // 获取首行地址
            IntPtr ptr = bmpData.Scan0;

            // 定义数组保存位图
            int bytes = Width * Height * 4;

            byte[] temp = rgbValues;

            // 把RGB值拷回位图
            System.Runtime.InteropServices.Marshal.Copy(temp, 0, ptr, bytes);

            // 解锁
            bitmap.UnlockBits(bmpData);
        }




        /// <summary>
        /// 将Color类型转为rgb数组
        /// </summary>
        /// <param name="color"></param>
        /// <returns></returns>
        private int[] RGB(int color)
        {
            int r = 0xFF & color;
            int g = 0xFF00 & color;
            g >>= 8;
            int b = 0xFF0000 & color;
            b >>= 16;
            return new int[3] { r, g, b };
        }
    }
}
