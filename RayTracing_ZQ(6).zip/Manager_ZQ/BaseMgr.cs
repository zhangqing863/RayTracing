﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ.Manager_ZQ
{
    public class BaseMgr<T>where T:new()
    {
        private static T mgr;
        public static T GetInstance()
        {
            if (mgr == null)
            {
                mgr = new T();
            }
            return mgr;
        }
    }
}
