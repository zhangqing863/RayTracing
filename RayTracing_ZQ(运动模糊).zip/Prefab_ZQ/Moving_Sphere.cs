﻿using RayTracing_ZQ.Base_ZQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ.Prefab_ZQ
{
    class Moving_Sphere : GeometryObject
    {
        //运动球体的起点与终点
        Point3D center0, center1;
        //运动球体的运动时间区间
        double time0, time1;
        double radius;
        public Moving_Sphere(Point3D center0, Point3D center1, double t0, double t1,double r)
        {
            this.center0 = center0;
            this.center1 = center1;
            time0 = t0;
            time1 = t1;
            radius = r;
        }
        public Moving_Sphere()
        {
            ObjTransform = new Transform(
                new MyMatrix(0, 0, 0),
                new MyMatrix(1, 1, 1),
                new MyMatrix(0, 0, 0)
                );
        }


        private Point3D Center(double time)
        {
            return center0 + ((time - time0) / (time1 - time0)) * (center1 - center0);
        }
        public const double KEpsilon = 1e-5;
        public override bool Hit(Ray ray, out ShadeRec sr)
        {
            Vector3D oc = ray.Origin - Center(ray.Time);
            double a = ray.Direction * ray.Direction;
            double b = 2 * (ray.Direction * oc);
            double c = oc * oc - radius * radius;
            double delta = b * b - 4 * a * c;
            sr = new ShadeRec();
            if (delta > 0)
            {
                //获取距离摄像机前方并离摄像机最近的t
                sr.T = (-b - Math.Sqrt(delta)) / (2 * a);
                if (sr.T < 0.00001)
                {
                    sr.T = (-b + Math.Sqrt(delta)) / (2 * a);
                }
                if (sr.T > KEpsilon)
                {
                    //击中点
                    sr.HitPoint = ray.GetHitPoint(sr.T);
                    //法线
                    sr.Normal = GetNormalVec3(sr.HitPoint, Center(ray.Time));
                    sr.IsHit = true;
                    sr.HitObjMat = Material;
                    sr.HitObjGlobalMat = GlobalMaterial;
                    sr.Geometry = this;
                    return true;
                }
                return false;
            }
            else
            {
                return false;
            }
        }

        public override bool ShadowHit(Ray ray)
        {
            Vector3D oc = ray.Origin - Center(ray.Time);
            double a = ray.Direction * ray.Direction;
            double b = 2 * (ray.Direction * oc);
            double c = oc * oc - radius * radius;
            double delta = b * b - 4 * a * c;
            if (delta > 0)
            {
                //获取距离摄像机前方并离摄像机最近的t
                double t = (-b - Math.Sqrt(delta)) / (2.0 * a);
                if (t > KEpsilon)
                {
                    return true;
                }
                else
                {
                    //t = (-b + Math.Sqrt(delta)) / (2.0 * a);
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 获取法线
        /// </summary>
        /// <param name="point">球面上的一点</param>
        /// <returns>法线向量</returns>
        public Vector3D GetNormalVec3(Point3D point, Point3D center)
        {
            return (point - center).Normalized;
        }
    }
}
