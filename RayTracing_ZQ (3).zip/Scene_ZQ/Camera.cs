﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 摄像机
    /// </summary>
    class Camera
    {
        private Point3D eye;//视线

        public Point3D Eye
        {
            get
            {
                return eye;
            }

            set
            {
                eye = value;
            }
        }
    }
}
