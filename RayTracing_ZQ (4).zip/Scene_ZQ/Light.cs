﻿using RayTracing_ZQ.Base_ZQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RayTracing_ZQ
{
    /// <summary>
    /// 光源
    /// </summary>
    class Light:MyObject
    {
        private Point3D pos;//光源位置
        private SColor lightColor;//光源颜色

        public Point3D Pos
        {
            get
            {
                return pos;
            }

            set
            {
                pos = value;
            }
        }


        public SColor LightColor
        {
            get
            {
                return lightColor;
            }

            set
            {
                lightColor = value;
            }
        }
    }
}
