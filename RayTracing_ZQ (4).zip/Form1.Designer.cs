﻿namespace RayTracing_ZQ
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.renderBtn = new System.Windows.Forms.Button();
            this.pic = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.renderRotateBar = new System.Windows.Forms.TrackBar();
            this.btnImport2AVI = new System.Windows.Forms.Button();
            this.renderProgressBar = new System.Windows.Forms.ProgressBar();
            this.label3 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.objGpBox = new System.Windows.Forms.GroupBox();
            this.RstioGpBox = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.objFlpanel = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.renderRotateBar)).BeginInit();
            this.objGpBox.SuspendLayout();
            this.RstioGpBox.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // renderBtn
            // 
            this.renderBtn.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.renderBtn.Location = new System.Drawing.Point(51, 271);
            this.renderBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.renderBtn.Name = "renderBtn";
            this.renderBtn.Size = new System.Drawing.Size(148, 82);
            this.renderBtn.TabIndex = 0;
            this.renderBtn.Text = "渲染";
            this.renderBtn.UseVisualStyleBackColor = true;
            this.renderBtn.Click += new System.EventHandler(this.renderBtn_Click);
            // 
            // pic
            // 
            this.pic.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.pic.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic.Location = new System.Drawing.Point(7, 24);
            this.pic.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pic.Name = "pic";
            this.pic.Size = new System.Drawing.Size(800, 401);
            this.pic.TabIndex = 1;
            this.pic.TabStop = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.label1.Location = new System.Drawing.Point(9, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(249, 43);
            this.label1.TabIndex = 2;
            this.label1.Text = "张庆_201731062511";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTime
            // 
            this.lblTime.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lblTime.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.lblTime.Location = new System.Drawing.Point(5, 426);
            this.lblTime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(801, 28);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "渲染时间";
            this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(51, 112);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(148, 82);
            this.button2.TabIndex = 0;
            this.button2.Text = "设置纹理";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // renderRotateBar
            // 
            this.renderRotateBar.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.renderRotateBar.Location = new System.Drawing.Point(311, 66);
            this.renderRotateBar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.renderRotateBar.Maximum = 360;
            this.renderRotateBar.Name = "renderRotateBar";
            this.renderRotateBar.Size = new System.Drawing.Size(758, 45);
            this.renderRotateBar.TabIndex = 4;
            this.renderRotateBar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.renderRotateBar_MouseUp);
            // 
            // btnImport2AVI
            // 
            this.btnImport2AVI.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImport2AVI.Location = new System.Drawing.Point(51, 443);
            this.btnImport2AVI.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnImport2AVI.Name = "btnImport2AVI";
            this.btnImport2AVI.Size = new System.Drawing.Size(148, 82);
            this.btnImport2AVI.TabIndex = 0;
            this.btnImport2AVI.Text = "导出AVI";
            this.btnImport2AVI.UseVisualStyleBackColor = true;
            this.btnImport2AVI.Click += new System.EventHandler(this.btnImport2AVI_Click);
            // 
            // renderProgressBar
            // 
            this.renderProgressBar.Location = new System.Drawing.Point(7, 16);
            this.renderProgressBar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.renderProgressBar.Name = "renderProgressBar";
            this.renderProgressBar.Size = new System.Drawing.Size(800, 8);
            this.renderProgressBar.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.label3.Location = new System.Drawing.Point(257, 67);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 45);
            this.label3.TabIndex = 2;
            this.label3.Text = "旋转";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // objGpBox
            // 
            this.objGpBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.objGpBox.BackColor = System.Drawing.Color.Transparent;
            this.objGpBox.Controls.Add(this.RstioGpBox);
            this.objGpBox.Controls.Add(this.objFlpanel);
            this.objGpBox.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.objGpBox.ForeColor = System.Drawing.Color.White;
            this.objGpBox.Location = new System.Drawing.Point(1086, 67);
            this.objGpBox.Name = "objGpBox";
            this.objGpBox.Size = new System.Drawing.Size(239, 462);
            this.objGpBox.TabIndex = 6;
            this.objGpBox.TabStop = false;
            this.objGpBox.Text = "Object";
            // 
            // RstioGpBox
            // 
            this.RstioGpBox.Controls.Add(this.label4);
            this.RstioGpBox.Controls.Add(this.label2);
            this.RstioGpBox.Controls.Add(this.txtHeight);
            this.RstioGpBox.Controls.Add(this.txtWidth);
            this.RstioGpBox.Font = new System.Drawing.Font("Segoe UI Symbol", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RstioGpBox.ForeColor = System.Drawing.Color.White;
            this.RstioGpBox.Location = new System.Drawing.Point(19, 20);
            this.RstioGpBox.Name = "RstioGpBox";
            this.RstioGpBox.Size = new System.Drawing.Size(200, 74);
            this.RstioGpBox.TabIndex = 1;
            this.RstioGpBox.TabStop = false;
            this.RstioGpBox.Text = "Resolution";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI Symbol", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(126, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Height";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI Symbol", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Width";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(128, 40);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(66, 23);
            this.txtHeight.TabIndex = 0;
            this.txtHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtHeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(6, 40);
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(66, 23);
            this.txtWidth.TabIndex = 0;
            this.txtWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtWidth.TextChanged += new System.EventHandler(this.txtWidth_TextChanged);
            this.txtWidth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWidth_KeyPress);
            // 
            // objFlpanel
            // 
            this.objFlpanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.objFlpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.objFlpanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.objFlpanel.Location = new System.Drawing.Point(19, 100);
            this.objFlpanel.Name = "objFlpanel";
            this.objFlpanel.Size = new System.Drawing.Size(200, 344);
            this.objFlpanel.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panel1.Controls.Add(this.pic);
            this.panel1.Controls.Add(this.lblTime);
            this.panel1.Controls.Add(this.renderProgressBar);
            this.panel1.Location = new System.Drawing.Point(257, 99);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(814, 462);
            this.panel1.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(1337, 606);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.objGpBox);
            this.Controls.Add(this.renderRotateBar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnImport2AVI);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.renderBtn);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "张庆";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.renderRotateBar)).EndInit();
            this.objGpBox.ResumeLayout(false);
            this.RstioGpBox.ResumeLayout(false);
            this.RstioGpBox.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button renderBtn;
        private System.Windows.Forms.PictureBox pic;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TrackBar renderRotateBar;
        private System.Windows.Forms.Button btnImport2AVI;
        private System.Windows.Forms.ProgressBar renderProgressBar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox objGpBox;
        private System.Windows.Forms.FlowLayoutPanel objFlpanel;
        private System.Windows.Forms.GroupBox RstioGpBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.Panel panel1;
    }
}

