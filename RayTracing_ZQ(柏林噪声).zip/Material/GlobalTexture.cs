﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RayTracing_ZQ
{

    public abstract class GlobalTexture
    {
        public abstract SColor Value(double u, double v, Point3D p);
    }


    /// <summary>
    /// 具体的纹理 适用于全局光照
    /// </summary>
    class Constant_Texture : GlobalTexture
    {
        SColor txtureColor;
        public Constant_Texture()
        {

        }
        public Constant_Texture(SColor sColor)
        {
            txtureColor = sColor;
        }
        public override SColor Value(double u, double v, Point3D p)
        {
            return txtureColor;
        }
    }

    /// <summary>
    /// 棋盘纹理
    /// </summary>
    class Checker_Texture : GlobalTexture
    {
        GlobalTexture odd, even;
        public Checker_Texture(GlobalTexture odd, GlobalTexture even)
        {
            this.odd = odd;
            this.even = even;
        }
        public override SColor Value(double u, double v, Point3D p)
        {
            double sines = Math.Sin(10 * p.X) * Math.Sin(10 * p.Y) * Math.Sin(10 * p.Z);
            if (sines < 0)
                return odd.Value(u, v, p);
            else
                return even.Value(u, v, p);
        }
    }

    /// <summary>
    /// 图片纹理
    /// </summary>
    class Image_Texture : GlobalTexture
    {
        Bitmap bitmap;
        public Image_Texture()
        {

        }
        public Image_Texture(Bitmap bitmap)
        {
            this.bitmap = bitmap;

        }
        public override SColor Value(double u, double v, Point3D p)
        {
            int i = (int)((bitmap.Width - 1) * u);
            int j = (int)((bitmap.Height - 1) * v);
            j = bitmap.Height - j - 1;
            double r = (bitmap.GetPixel(i, j).R / 255.0);
            double g = (bitmap.GetPixel(i, j).G / 255.0);
            double b = (bitmap.GetPixel(i, j).B / 255.0);
            return new SColor(r, g, b);
        }
    }

    /// <summary>
    /// 柏林噪声纹理
    /// </summary>
    class Noise_Texture:GlobalTexture
    {
        PerlinNoise noise = new PerlinNoise();
        double scale;//缩放率
        public Noise_Texture(double scale)
        {
            this.scale = scale;
        }
        public override SColor Value(double u, double v, Point3D p)
        {
            return new SColor(1, 1, 1) * 0.5 * (1 + Math.Sin(scale * p.Z + 10 * noise.Turb(p)));
        }
    }

}
